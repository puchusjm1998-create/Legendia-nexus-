/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Swords,
  Sparkles,
  Users,
  Shield,
  BookOpen,
  Smartphone,
  Play,
  Flame,
  Zap,
  Star,
  ChevronRight,
} from 'lucide-react';
import type {
  PlayerCharacter,
  EnemyCharacter,
  PlayerProfile,
  PlayerInventory,
  StoryChapter,
} from './game/types.ts';
import { loadGameData, saveGameData, resetSaveData, type GameSaveData } from './game/storage.ts';
import { sound } from './game/audio.ts';
import { bgImage } from './game/database.ts';

// Components
import { TitleScreen } from './components/TitleScreen.tsx';
import { TopBar } from './components/TopBar.tsx';
import { BattleView } from './components/BattleView.tsx';
import { SummonView } from './components/SummonView.tsx';
import { HeroesView } from './components/HeroesView.tsx';
import { TeamFormationView } from './components/TeamFormationView.tsx';
import { StoryModesView } from './components/StoryModesView.tsx';
import { AndroidModal } from './components/AndroidModal.tsx';

export default function App() {
  // Load persistent savedata
  const [saveData, setSaveData] = useState<GameSaveData>(() => loadGameData());

  // Game state: 'title' | 'lobby' | 'battle'
  const [gameState, setGameState] = useState<'title' | 'lobby' | 'battle'>('title');

  // Lobby Tab: 'modes' | 'summon' | 'heroes' | 'formation'
  const [activeTab, setActiveTab] = useState<'modes' | 'summon' | 'heroes' | 'formation'>('modes');

  // Audio mute state
  const [isMuted, setIsMuted] = useState<boolean>(() => sound.getMuted());

  // Android compilation modal
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);

  // Active Battle Parameters
  const [activeBattleParams, setActiveBattleParams] = useState<{
    enemies: EnemyCharacter[];
    title: string;
    onSuccessRewards?: { gold: number; exp: number; gems: number; episodeId?: string };
  } | null>(null);

  // Check ?autostart=1 in URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      setGameState('lobby');
      document.body.dataset.state = 'playing';
    }
  }, []);

  // Sync document.body.dataset.state with game state
  useEffect(() => {
    if (gameState === 'title') {
      document.body.dataset.state = 'title';
    } else {
      document.body.dataset.state = 'playing';
    }
  }, [gameState]);

  // Auto-save on state change
  useEffect(() => {
    saveGameData(saveData);
  }, [saveData]);

  // Audio toggle
  const handleToggleMute = useCallback(() => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  }, []);

  // Title to Lobby
  const handleStartGame = useCallback(() => {
    sound.playClick();
    setGameState('lobby');
  }, []);

  // Reset Game Data
  const handleResetData = useCallback(() => {
    const fresh = resetSaveData();
    setSaveData(fresh);
    setGameState('title');
  }, []);

  // Update Inventory helper
  const handleUpdateInventory = useCallback((newInv: PlayerInventory) => {
    setSaveData((prev) => ({ ...prev, inventory: newInv }));
  }, []);

  // Update Characters helper
  const handleUpdateCharacters = useCallback((newCharacters: PlayerCharacter[]) => {
    setSaveData((prev) => ({ ...prev, characters: newCharacters }));
  }, []);

  // Update single character
  const handleUpdateSingleCharacter = useCallback((char: PlayerCharacter) => {
    setSaveData((prev) => ({
      ...prev,
      characters: prev.characters.map((c) => (c.id === char.id ? char : c)),
    }));
  }, []);

  // Update Team
  const handleUpdateTeam = useCallback((newTeamIds: string[]) => {
    setSaveData((prev) => ({ ...prev, activeTeamIds: newTeamIds }));
  }, []);

  // Update Profile
  const handleUpdateProfile = useCallback((newProf: PlayerProfile) => {
    setSaveData((prev) => ({ ...prev, profile: newProf }));
  }, []);

  // Update Pity
  const handleUpdatePity = useCallback((bannerId: string, count: number) => {
    setSaveData((prev) => ({
      ...prev,
      pityCounts: { ...prev.pityCounts, [bannerId]: count },
    }));
  }, []);

  // Add Summon History
  const handleAddHistory = useCallback(
    (
      entries: Array<{
        characterId: string;
        characterName: string;
        rarity: string;
        timestamp: number;
        bannerName: string;
      }>
    ) => {
      setSaveData((prev) => ({
        ...prev,
        summonHistory: [...prev.summonHistory, ...entries],
      }));
    },
    []
  );

  // Start a battle
  const handleStartBattle = useCallback(
    (
      enemies: EnemyCharacter[],
      title: string,
      rewards?: { gold: number; exp: number; gems: number; episodeId?: string }
    ) => {
      sound.playClick();
      setActiveBattleParams({
        enemies,
        title,
        onSuccessRewards: rewards,
      });
      setGameState('battle');
    },
    []
  );

  // Battle Victory Callback
  const handleBattleVictory = useCallback(
    (rewards: { gold: number; exp: number; gems: number }) => {
      setSaveData((prev) => {
        const nextInv: PlayerInventory = {
          ...prev.inventory,
          gold: prev.inventory.gold + rewards.gold,
          nexusGems: prev.inventory.nexusGems + rewards.gems,
          expOrbs: prev.inventory.expOrbs + Math.max(2, Math.floor(rewards.exp / 250)),
        };

        const nextProf: PlayerProfile = {
          ...prev.profile,
          exp: prev.profile.exp + rewards.exp,
          totalBattlesWon: prev.profile.totalBattlesWon + 1,
          highestTowerFloor:
            activeBattleParams?.title.includes('Torre')
              ? prev.profile.highestTowerFloor + 1
              : prev.profile.highestTowerFloor,
        };

        // Level up player profile if exp threshold reached
        if (nextProf.exp >= nextProf.maxExp) {
          nextProf.level += 1;
          nextProf.exp -= nextProf.maxExp;
          nextProf.maxExp = Math.round(nextProf.maxExp * 1.5);
          nextProf.maxStamina += 10;
          nextProf.stamina = nextProf.maxStamina;
        }

        // If story episode was completed, mark stars
        let updatedChapters = prev.storyChapters;
        if (activeBattleParams?.onSuccessRewards?.episodeId) {
          const epId = activeBattleParams.onSuccessRewards.episodeId;
          updatedChapters = prev.storyChapters.map((ch) => ({
            ...ch,
            episodes: ch.episodes.map((ep) =>
              ep.id === epId ? { ...ep, completed: true, stars: 3 } : ep
            ),
          }));
        }

        return {
          ...prev,
          inventory: nextInv,
          profile: nextProf,
          storyChapters: updatedChapters,
        };
      });

      setGameState('lobby');
      setActiveBattleParams(null);
    },
    [activeBattleParams]
  );

  // Battle Defeat Callback
  const handleBattleDefeat = useCallback(() => {
    setGameState('lobby');
    setActiveBattleParams(null);
  }, []);

  // Exit Battle without rewards
  const handleExitBattle = useCallback(() => {
    setGameState('lobby');
    setActiveBattleParams(null);
  }, []);

  // Active 4 Heroes in Squad
  const activeHeroes = saveData.activeTeamIds
    .map((id) => saveData.characters.find((c) => c.id === id))
    .filter(Boolean) as PlayerCharacter[];

  // Fallback if empty
  const heroShowcase = activeHeroes[0] || saveData.characters[0];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans select-none flex flex-col">
      {/* 1. TITLE SCREEN */}
      {gameState === 'title' && (
        <TitleScreen
          onStart={handleStartGame}
          onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* 2. MAIN LOBBY INTERFACE */}
      {gameState === 'lobby' && (
        <div className="relative w-full h-full flex flex-col overflow-hidden bg-slate-950">
          {/* Panoramic Nexus Background */}
          <div
            className="absolute inset-0 bg-cover bg-center brightness-[0.35]"
            style={{ backgroundImage: `url(${bgImage})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-slate-950/80 pointer-events-none" />

          {/* Top Bar with Profile & Currencies */}
          <TopBar
            profile={saveData.profile}
            inventory={saveData.inventory}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
            onResetData={handleResetData}
          />

          {/* Main Content Area */}
          <main className="relative z-10 flex-1 overflow-hidden flex flex-col">
            {activeTab === 'modes' && (
              <StoryModesView
                chapters={saveData.storyChapters}
                profile={saveData.profile}
                inventory={saveData.inventory}
                activeHeroes={activeHeroes}
                onStartBattle={handleStartBattle}
                onUpdateInventory={handleUpdateInventory}
                onUpdateProfile={handleUpdateProfile}
              />
            )}

            {activeTab === 'summon' && (
              <SummonView
                inventory={saveData.inventory}
                unlockedCharacters={saveData.characters}
                pityCounts={saveData.pityCounts}
                summonHistory={saveData.summonHistory}
                onUpdateInventory={handleUpdateInventory}
                onAddCharacters={handleUpdateCharacters}
                onUpdatePity={handleUpdatePity}
                onAddHistory={handleAddHistory}
              />
            )}

            {activeTab === 'heroes' && (
              <HeroesView
                characters={saveData.characters}
                inventory={saveData.inventory}
                onUpdateCharacter={handleUpdateSingleCharacter}
                onUpdateInventory={handleUpdateInventory}
              />
            )}

            {activeTab === 'formation' && (
              <TeamFormationView
                characters={saveData.characters}
                activeTeamIds={saveData.activeTeamIds}
                onUpdateTeam={handleUpdateTeam}
              />
            )}
          </main>

          {/* Bottom Main Navigation Dock */}
          <nav className="relative z-20 w-full bg-slate-950/95 backdrop-blur-md border-t border-purple-500/20 px-4 py-2 flex items-center justify-around max-w-4xl mx-auto rounded-t-3xl shadow-2xl">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('modes');
              }}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition cursor-pointer ${
                activeTab === 'modes'
                  ? 'text-amber-400 font-extrabold scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Swords className="w-5 h-5" />
              <span className="text-[10px] sm:text-xs font-title uppercase tracking-wide">
                Combate
              </span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('summon');
              }}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition cursor-pointer ${
                activeTab === 'summon'
                  ? 'text-amber-400 font-extrabold scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-5 h-5" />
              <span className="text-[10px] sm:text-xs font-title uppercase tracking-wide">
                Invocación
              </span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('heroes');
              }}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition cursor-pointer ${
                activeTab === 'heroes'
                  ? 'text-amber-400 font-extrabold scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Star className="w-5 h-5" />
              <span className="text-[10px] sm:text-xs font-title uppercase tracking-wide">
                Héroes
              </span>
            </button>

            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('formation');
              }}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-2xl transition cursor-pointer ${
                activeTab === 'formation'
                  ? 'text-amber-400 font-extrabold scale-110 drop-shadow-[0_0_8px_rgba(245,158,11,0.6)]'
                : 'text-slate-400 hover:text-white'
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="text-[10px] sm:text-xs font-title uppercase tracking-wide">
                Escuadrón
              </span>
            </button>
          </nav>
        </div>
      )}

      {/* 3. BATTLE ARENA VIEW */}
      {gameState === 'battle' && activeBattleParams && (
        <BattleView
          initialHeroes={activeHeroes}
          initialEnemies={activeBattleParams.enemies}
          battleTitle={activeBattleParams.title}
          onVictory={handleBattleVictory}
          onDefeat={handleBattleDefeat}
          onExit={handleExitBattle}
        />
      )}

      {/* 4. ANDROID COMPILATION MODAL */}
      <AndroidModal
        isOpen={isAndroidModalOpen}
        onClose={() => setIsAndroidModalOpen(false)}
      />
    </div>
  );
}
