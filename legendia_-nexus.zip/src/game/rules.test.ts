/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getElementalMultiplier,
  calculateStarMultiplier,
  calculateExpForLevel,
  calculateDamage,
  calculateTeamSynergies,
  checkBattleStatus,
  calculateTurnOrder,
  rollGachaSingle,
} from './rules.ts';

test('Elemental advantage table cycles correctly', () => {
  // Fuego > Viento
  assert.equal(getElementalMultiplier('fuego', 'viento'), 1.35);
  assert.equal(getElementalMultiplier('viento', 'fuego'), 0.75);

  // Viento > Rayo
  assert.equal(getElementalMultiplier('viento', 'rayo'), 1.35);
  assert.equal(getElementalMultiplier('rayo', 'viento'), 0.75);

  // Rayo > Agua
  assert.equal(getElementalMultiplier('rayo', 'agua'), 1.35);
  assert.equal(getElementalMultiplier('agua', 'rayo'), 0.75);

  // Agua > Fuego
  assert.equal(getElementalMultiplier('agua', 'fuego'), 1.35);
  assert.equal(getElementalMultiplier('fuego', 'agua'), 0.75);

  // Neutral same element
  assert.equal(getElementalMultiplier('fuego', 'fuego'), 1.0);

  // Luz and Oscuridad mutual bonus
  assert.equal(getElementalMultiplier('luz', 'oscuridad'), 1.3);
  assert.equal(getElementalMultiplier('oscuridad', 'luz'), 1.3);
});

test('Star multiplier scales progressively up to 14 stars', () => {
  assert.equal(calculateStarMultiplier(1), 1.0);
  // 5 stars = 1.0 + 4 * 0.08 = 1.32
  assert.equal(calculateStarMultiplier(5), 1.32);
  // 10 stars (Red) = 1.32 + 5 * 0.12 = 1.92
  assert.equal(calculateStarMultiplier(10), 1.92);
  // 14 stars (Nexus Transcendence) = 1.92 + 4 * 0.15 = 2.52
  assert.equal(calculateStarMultiplier(14), 2.52);
  // Clamped bounds
  assert.equal(calculateStarMultiplier(0), 1.0);
  assert.equal(calculateStarMultiplier(20), 2.52);
});

test('Exp calculation scales predictably by level', () => {
  assert.equal(calculateExpForLevel(1), 100);
  assert.ok(calculateExpForLevel(10) > calculateExpForLevel(5));
  assert.ok(calculateExpForLevel(50) > calculateExpForLevel(20));
});

test('Damage calculation handles elemental advantages and defense', () => {
  const resultAdvantage = calculateDamage({
    attackerAtk: 1000,
    attackerElement: 'fuego',
    defenderDef: 200,
    defenderElement: 'viento',
    skillMultiplier: 1.5,
    critChance: 0,
    randomFactor: 1.0,
  });

  const resultDisadvantage = calculateDamage({
    attackerAtk: 1000,
    attackerElement: 'viento',
    defenderDef: 200,
    defenderElement: 'fuego',
    skillMultiplier: 1.5,
    critChance: 0,
    randomFactor: 1.0,
  });

  assert.ok(resultAdvantage.damage > resultDisadvantage.damage);
  assert.equal(resultAdvantage.elementMultiplier, 1.35);
  assert.equal(resultDisadvantage.elementMultiplier, 0.75);
});

test('Team synergy detects single universe boosts and full Nexus convergence', () => {
  const saiyanSynergy = calculateTeamSynergies(['dragon_ball', 'dragon_ball']);
  assert.ok(saiyanSynergy.atkBonus >= 0.15);
  assert.equal(saiyanSynergy.nexusConvergence, false);

  const fullConvergence = calculateTeamSynergies([
    'dragon_ball',
    'naruto',
    'final_fantasy',
    'dragon_ball',
  ]);
  assert.equal(fullConvergence.nexusConvergence, true);
  assert.ok(fullConvergence.atkBonus > 0.2); // saiyan bonus + nexus bonus
});

test('Battle status correctly signals victory, defeat, or playing', () => {
  assert.equal(checkBattleStatus(4, 0), 'victory');
  assert.equal(checkBattleStatus(0, 3), 'defeat');
  assert.equal(checkBattleStatus(2, 1), 'playing');
});

test('Turn order is sorted descending by speed', () => {
  const order = calculateTurnOrder([
    { id: '1', isHero: true, index: 0, spd: 110, isAlive: true },
    { id: '2', isHero: true, index: 1, spd: 135, isAlive: true },
    { id: '3', isHero: false, index: 0, spd: 120, isAlive: true },
    { id: '4', isHero: false, index: 1, spd: 90, isAlive: false }, // Dead combatant should be excluded
  ]);

  assert.equal(order.length, 3);
  assert.equal(order[0].spd, 135);
  assert.equal(order[1].spd, 120);
  assert.equal(order[2].spd, 110);
});

test('Gacha pity triggers guaranteed UR and SSR at thresholds', () => {
  const testPool = {
    UR: ['ur_char'],
    SSR: ['ssr_char'],
    SR: ['sr_char'],
    R: ['r_char'],
  };

  const urPity = rollGachaSingle(testPool, 79);
  assert.equal(urPity.rarity, 'UR');
  assert.equal(urPity.isPityTriggered, true);

  const ssrPity = rollGachaSingle(testPool, 49);
  assert.equal(ssrPity.rarity, 'SSR');
  assert.equal(ssrPity.isPityTriggered, true);
});
