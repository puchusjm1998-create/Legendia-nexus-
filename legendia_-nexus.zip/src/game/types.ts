/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Universe = 'dragon_ball' | 'naruto' | 'final_fantasy';
export type Element = 'fuego' | 'agua' | 'viento' | 'rayo' | 'luz' | 'oscuridad';
export type Rarity = 'R' | 'SR' | 'SSR' | 'UR';
export type SkillTarget = 'single_enemy' | 'all_enemies' | 'single_ally' | 'all_allies' | 'self';

export interface StatusEffect {
  id: string;
  name: string;
  type: 'burn' | 'stun' | 'shield' | 'atk_up' | 'def_down' | 'regen' | 'chakra_boost';
  duration: number; // turns
  value: number; // damage percentage, shield amount, or stat multiplier
  description: string;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  energyCost: number; // Ki, Chakra or MP
  target: SkillTarget;
  multiplier: number; // damage multiplier on ATK
  healingMultiplier?: number; // heal multiplier
  cooldown: number; // in turns
  currentCooldown?: number;
  statusEffects?: StatusEffect[];
  isUltimate?: boolean;
  visualEffect: 'ki_beam' | 'energy_barrage' | 'jutsu_fire' | 'chidori_strike' | 'crystal_blade' | 'meteor_rain' | 'sacred_light' | 'void_rift';
  quote?: string;
}

export interface CharacterBase {
  id: string;
  name: string;
  title: string;
  universe: Universe;
  element: Element;
  rarity: Rarity;
  avatar: string;
  lore: string;
  personality: string;
  quote: string;
  baseHp: number;
  baseAtk: number;
  baseDef: number;
  baseSpd: number;
  baseCrit: number; // e.g. 0.15 = 15%
  basicAttack: Skill;
  skill1: Skill;
  skill2: Skill;
  ultimate: Skill;
  synergyBonus: {
    targetUniverse: Universe;
    stat: 'atk' | 'hp' | 'def' | 'spd';
    bonusPercent: number;
    description: string;
  };
}

export interface PlayerCharacter extends CharacterBase {
  level: number;
  exp: number;
  maxExp: number;
  stars: number; // 1 to 14 stars (1-5 yellow, 6-10 red, 11-14 rainbow/nexus)
  shards: number;
  currentHp: number;
  maxHp: number;
  currentEnergy: number; // 0 to 100
  nexusRage: number; // 0 to 100 (for Ultimate)
  currentAtk: number;
  currentDef: number;
  currentSpd: number;
  activeEffects: StatusEffect[];
  isAlive: boolean;
  equipment?: {
    weapon?: string;
    armor?: string;
    accessory?: string;
  };
}

export interface EnemyCharacter {
  id: string;
  name: string;
  title: string;
  universe: Universe | 'void';
  element: Element;
  avatar: string;
  level: number;
  hp: number;
  maxHp: number;
  atk: number;
  def: number;
  spd: number;
  crit: number;
  basicAttack: Skill;
  skill1: Skill;
  ultimate?: Skill;
  nexusRage: number;
  activeEffects: StatusEffect[];
  isAlive: boolean;
  isBoss?: boolean;
  drops: {
    gold: number;
    exp: number;
    gems: number;
    shardsChance?: { characterId: string; chance: number; amount: number };
  };
}

export interface CombatActionLog {
  id: string;
  actorName: string;
  skillName: string;
  targetNames: string[];
  damageDealt?: number[];
  healingDone?: number[];
  isCrit?: boolean[];
  statusApplied?: string[];
  message: string;
  timestamp: number;
}

export interface BattleState {
  heroes: PlayerCharacter[];
  enemies: EnemyCharacter[];
  currentTurnIndex: number;
  turnOrder: Array<{ isHero: boolean; index: number; spd: number }>;
  currentActor: { isHero: boolean; index: number } | null;
  selectedTargetIndex: number;
  phase: 'idle' | 'animating' | 'action_select' | 'victory' | 'defeat';
  actionLog: CombatActionLog[];
  round: number;
  animatingSkill: {
    skill: Skill;
    attackerName: string;
    isHero: boolean;
    attackerIndex: number;
    targetIndices: number[];
  } | null;
  hitDamageNumbers: Array<{
    id: string;
    isHeroTarget: boolean;
    targetIndex: number;
    amount: number;
    isCrit: boolean;
    isHeal: boolean;
    element: Element;
  }>;
}

export interface SummonBanner {
  id: string;
  name: string;
  description: string;
  featuredUniverse?: Universe;
  featuredCharacterId?: string;
  bannerImage: string;
  costSingle: number; // Gems
  costMulti: number; // Gems (e.g. 10x for 2250, 10% discount)
  rates: {
    UR: number; // 0.015 (1.5%)
    SSR: number; // 0.045 (4.5%)
    SR: number; // 0.24 (24%)
    R: number; // 0.70 (70%)
  };
  pityThreshold: number; // Guaranteed SSR at 50, UR at 80
}

export interface PlayerInventory {
  gold: number;
  nexusGems: number; // Premium/Free summon currency
  summonTickets: number;
  expOrbs: number; // For leveling heroes
  starCrystals: number; // For star awakening
  awakeningStones: number;
}

export interface StoryChapter {
  id: number;
  title: string;
  description: string;
  episodes: StoryEpisode[];
}

export interface StoryEpisode {
  id: string;
  title: string;
  chapterId: number;
  dialogueIntro?: Array<{
    speaker: string;
    avatar: string;
    text: string;
  }>;
  dialogueOutro?: Array<{
    speaker: string;
    avatar: string;
    text: string;
  }>;
  enemyFormation: Array<Omit<EnemyCharacter, 'activeEffects' | 'isAlive' | 'nexusRage'>>;
  firstClearRewards: {
    gems: number;
    gold: number;
    expOrbs: number;
    shards?: { characterId: string; amount: number };
  };
  recommendedLevel: number;
  completed: boolean;
  stars: number; // 0 to 3
}

export interface PlayerProfile {
  name: string;
  level: number;
  exp: number;
  maxExp: number;
  stamina: number;
  maxStamina: number;
  highestTowerFloor: number;
  loginDaysCount: number;
  lastLoginDate: string;
  claimedLoginDays: number[];
  totalBattlesWon: number;
  totalSummonsDone: number;
}
