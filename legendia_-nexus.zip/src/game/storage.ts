/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type {
  PlayerCharacter,
  PlayerProfile,
  PlayerInventory,
  StoryChapter,
} from './types.ts';
import {
  createPlayerCharacter,
  INITIAL_PLAYER_PROFILE,
  INITIAL_INVENTORY,
  STORY_CHAPTERS,
} from './database.ts';

export interface GameSaveData {
  version: number;
  profile: PlayerProfile;
  inventory: PlayerInventory;
  characters: PlayerCharacter[];
  activeTeamIds: string[]; // up to 4 character IDs
  storyChapters: StoryChapter[];
  summonHistory: Array<{
    characterId: string;
    characterName: string;
    rarity: string;
    timestamp: number;
    bannerName: string;
  }>;
  pityCounts: Record<string, number>;
  towerFloor: number;
}

const STORAGE_KEY = 'legendia_nexus_savedata_v1';

export function createDefaultSave(): GameSaveData {
  // Rule 9: 3 initial heroes, one from each universe!
  const starter1 = createPlayerCharacter('kaeler_saiyan', 1, 1);
  const starter2 = createPlayerCharacter('renji_uchiha', 1, 1);
  const starter3 = createPlayerCharacter('aria_crystal', 1, 1);

  return {
    version: 1,
    profile: { ...INITIAL_PLAYER_PROFILE },
    inventory: { ...INITIAL_INVENTORY },
    characters: [starter1, starter2, starter3],
    activeTeamIds: ['kaeler_saiyan', 'renji_uchiha', 'aria_crystal'],
    storyChapters: JSON.parse(JSON.stringify(STORY_CHAPTERS)),
    summonHistory: [],
    pityCounts: {},
    towerFloor: 1,
  };
}

export function loadGameData(): GameSaveData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const def = createDefaultSave();
      saveGameData(def);
      return def;
    }
    const parsed = JSON.parse(raw) as GameSaveData;
    // Basic migration / validation guard
    if (!parsed.characters || parsed.characters.length === 0) {
      const def = createDefaultSave();
      saveGameData(def);
      return def;
    }
    return parsed;
  } catch (e) {
    console.error('Failed to load save data, resetting to default:', e);
    const def = createDefaultSave();
    saveGameData(def);
    return def;
  }
}

export function saveGameData(data: GameSaveData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save game data:', e);
  }
}

export function resetSaveData(): GameSaveData {
  localStorage.removeItem(STORAGE_KEY);
  const def = createDefaultSave();
  saveGameData(def);
  return def;
}
