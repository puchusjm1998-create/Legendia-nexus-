/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import type { Element, Skill, StatusEffect, Universe } from './types.ts';

/**
 * Elemental advantage table:
 * fuego (Fire) beats viento (Wind)
 * viento (Wind) beats rayo (Lightning)
 * rayo (Lightning) beats agua (Water)
 * agua (Water) beats fuego (Fire)
 * luz (Light) and oscuridad (Dark) deal 1.25x damage to each other
 */
export function getElementalMultiplier(attackerElem: Element, defenderElem: Element): number {
  if (attackerElem === defenderElem) return 1.0;

  // Elemental cycle: Fuego -> Viento -> Rayo -> Agua -> Fuego
  if (
    (attackerElem === 'fuego' && defenderElem === 'viento') ||
    (attackerElem === 'viento' && defenderElem === 'rayo') ||
    (attackerElem === 'rayo' && defenderElem === 'agua') ||
    (attackerElem === 'agua' && defenderElem === 'fuego')
  ) {
    return 1.35; // +35% advantage
  }

  // Disadvantage
  if (
    (attackerElem === 'viento' && defenderElem === 'fuego') ||
    (attackerElem === 'rayo' && defenderElem === 'viento') ||
    (attackerElem === 'agua' && defenderElem === 'rayo') ||
    (attackerElem === 'fuego' && defenderElem === 'agua')
  ) {
    return 0.75; // -25% reduction
  }

  // Light and Dark opposition
  if (
    (attackerElem === 'luz' && defenderElem === 'oscuridad') ||
    (attackerElem === 'oscuridad' && defenderElem === 'luz')
  ) {
    return 1.3; // Mutual +30% boost
  }

  return 1.0;
}

/**
 * Star multiplier for character stats up to 14 stars:
 * 1-5 stars (Bronze/Gold): +8% per star
 * 6-10 stars (Red Star Awakening): +12% per star
 * 11-14 stars (Nexus Rainbow Transcendence): +15% per star
 */
export function calculateStarMultiplier(stars: number): number {
  const clampedStars = Math.max(1, Math.min(14, Math.floor(stars)));
  let multiplier = 1.0;

  // Stars 2 to 5 (+8% each)
  const tier1 = Math.min(clampedStars, 5) - 1;
  multiplier += tier1 * 0.08;

  // Stars 6 to 10 (+12% each)
  if (clampedStars > 5) {
    const tier2 = Math.min(clampedStars, 10) - 5;
    multiplier += tier2 * 0.12;
  }

  // Stars 11 to 14 (+15% each)
  if (clampedStars > 10) {
    const tier3 = clampedStars - 10;
    multiplier += tier3 * 0.15;
  }

  return parseFloat(multiplier.toFixed(3));
}

/**
 * Calculates experience required to reach next level
 */
export function calculateExpForLevel(level: number): number {
  if (level <= 1) return 100;
  return Math.floor(100 * Math.pow(level, 1.45));
}

/**
 * Calculates raw and final damage with defense reduction, elemental affinity, and critical hit
 */
export interface DamageCalculationParams {
  attackerAtk: number;
  attackerElement: Element;
  defenderDef: number;
  defenderElement: Element;
  skillMultiplier: number;
  critChance: number;
  randomFactor?: number; // 0.95 to 1.05 for variation
  activeEffects?: StatusEffect[];
}

export interface DamageResult {
  damage: number;
  isCrit: boolean;
  elementMultiplier: number;
  effectiveAtk: number;
  effectiveDef: number;
}

export function calculateDamage(params: DamageCalculationParams): DamageResult {
  const {
    attackerAtk,
    attackerElement,
    defenderDef,
    defenderElement,
    skillMultiplier,
    critChance,
    randomFactor = 1.0,
    activeEffects = [],
  } = params;

  let effectiveAtk = attackerAtk;
  let effectiveDef = defenderDef;

  // Check active status effects
  for (const eff of activeEffects) {
    if (eff.type === 'atk_up') {
      effectiveAtk *= 1 + eff.value;
    }
    if (eff.type === 'def_down') {
      effectiveDef = Math.max(0, effectiveDef * (1 - eff.value));
    }
  }

  // Element multiplier
  const elementMultiplier = getElementalMultiplier(attackerElement, defenderElement);

  // Critical hit check
  const clampedCrit = Math.max(0, Math.min(0.85, critChance));
  const isCrit = Math.random() < clampedCrit;
  const critMultiplier = isCrit ? 1.5 : 1.0;

  // Defense mitigation formula: Damage = (ATK * Multiplier) * (1000 / (1000 + DEF * 2.5))
  const rawPower = effectiveAtk * skillMultiplier;
  const defenseMitigation = 1000 / (1000 + Math.max(0, effectiveDef) * 2.2);
  const baseDamage = rawPower * defenseMitigation;

  const finalDamage = Math.max(
    1,
    Math.round(baseDamage * elementMultiplier * critMultiplier * randomFactor)
  );

  return {
    damage: finalDamage,
    isCrit,
    elementMultiplier,
    effectiveAtk: Math.round(effectiveAtk),
    effectiveDef: Math.round(effectiveDef),
  };
}

/**
 * Calculates healing based on character ATK/skill multiplier
 */
export function calculateHealing(healerAtk: number, healingMultiplier: number): number {
  return Math.max(1, Math.round(healerAtk * healingMultiplier));
}

/**
 * Determines team synergy bonus based on composition
 */
export function calculateTeamSynergies(universes: Universe[]): {
  atkBonus: number;
  defBonus: number;
  hpBonus: number;
  nexusConvergence: boolean;
  descriptions: string[];
} {
  const counts = {
    dragon_ball: 0,
    naruto: 0,
    final_fantasy: 0,
  };

  for (const u of universes) {
    if (counts[u] !== undefined) {
      counts[u]++;
    }
  }

  let atkBonus = 0;
  let defBonus = 0;
  let hpBonus = 0;
  const descriptions: string[] = [];

  // Dragon Ball synergy: Saiyan Fierce Spirit (+10% ATK per Saiyan)
  if (counts.dragon_ball >= 2) {
    atkBonus += 0.15;
    descriptions.push(`Espíritu Saiyajin (${counts.dragon_ball} guerreros): +15% ATK`);
  }

  // Naruto synergy: Will of Fire (+12% SPD & +10% HP)
  if (counts.naruto >= 2) {
    hpBonus += 0.15;
    descriptions.push(`Voluntad de Fuego (${counts.naruto} ninjas): +15% HP Máx`);
  }

  // Final Fantasy synergy: Crystal Aegis (+15% DEF)
  if (counts.final_fantasy >= 2) {
    defBonus += 0.15;
    descriptions.push(`Égida del Cristal (${counts.final_fantasy} héroes): +15% DEF`);
  }

  // Nexus Convergence: If all 3 universes are represented in the team!
  const hasAllThree =
    counts.dragon_ball >= 1 && counts.naruto >= 1 && counts.final_fantasy >= 1;

  if (hasAllThree) {
    atkBonus += 0.10;
    defBonus += 0.10;
    hpBonus += 0.10;
    descriptions.push('¡Convergencia del Nexo! (3 Universos Unidos): +10% a todas las estadísticas');
  }

  return {
    atkBonus,
    defBonus,
    hpBonus,
    nexusConvergence: hasAllThree,
    descriptions,
  };
}

/**
 * Checks win and loss conditions
 */
export function checkBattleStatus(
  heroesAliveCount: number,
  enemiesAliveCount: number
): 'playing' | 'victory' | 'defeat' {
  if (enemiesAliveCount === 0) return 'victory';
  if (heroesAliveCount === 0) return 'defeat';
  return 'playing';
}

/**
 * Sorts battle combatants by speed to determine turn order queue
 */
export function calculateTurnOrder(
  combatants: Array<{ id: string; isHero: boolean; index: number; spd: number; isAlive: boolean }>
): Array<{ isHero: boolean; index: number; spd: number }> {
  return combatants
    .filter((c) => c.isAlive)
    .sort((a, b) => b.spd - a.spd)
    .map((c) => ({ isHero: c.isHero, index: c.index, spd: c.spd }));
}

/**
 * Gacha pull outcome simulation with pity guarantee
 */
export interface GachaPool {
  UR: string[];
  SSR: string[];
  SR: string[];
  R: string[];
}

export interface GachaPullResult {
  characterId: string;
  rarity: 'UR' | 'SSR' | 'SR' | 'R';
  isPityTriggered: boolean;
}

export function rollGachaSingle(
  pool: GachaPool,
  pityCount: number,
  isGuaranteedSR: boolean = false
): GachaPullResult {
  // Pity system: Guaranteed UR at 80, Guaranteed SSR at 50
  if (pityCount >= 79) {
    const randomUR = pool.UR[Math.floor(Math.random() * pool.UR.length)];
    return { characterId: randomUR, rarity: 'UR', isPityTriggered: true };
  }

  if (pityCount >= 49) {
    const randomSSR = pool.SSR[Math.floor(Math.random() * pool.SSR.length)];
    return { characterId: randomSSR, rarity: 'SSR', isPityTriggered: true };
  }

  const roll = Math.random();

  // Rates: UR 1.5%, SSR 4.5%, SR 24%, R 70%
  if (roll < 0.015 && pool.UR.length > 0) {
    const char = pool.UR[Math.floor(Math.random() * pool.UR.length)];
    return { characterId: char, rarity: 'UR', isPityTriggered: false };
  }

  if (roll < 0.06 && pool.SSR.length > 0) {
    // 0.015 + 0.045 = 0.06
    const char = pool.SSR[Math.floor(Math.random() * pool.SSR.length)];
    return { characterId: char, rarity: 'SSR', isPityTriggered: false };
  }

  if ((roll < 0.30 || isGuaranteedSR) && pool.SR.length > 0) {
    // 0.06 + 0.24 = 0.30
    const char = pool.SR[Math.floor(Math.random() * pool.SR.length)];
    return { characterId: char, rarity: 'SR', isPityTriggered: false };
  }

  const char = pool.R[Math.floor(Math.random() * pool.R.length)];
  return { characterId: char, rarity: 'R', isPityTriggered: false };
}
