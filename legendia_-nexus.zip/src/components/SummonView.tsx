/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Sparkles,
  Ticket,
  Info,
  Clock,
  History,
  CheckCircle,
  X,
  Flame,
  Zap,
} from 'lucide-react';
import type {
  SummonBanner,
  PlayerInventory,
  PlayerCharacter,
  Rarity,
} from '../game/types.ts';
import { rollGachaSingle } from '../game/rules.ts';
import { sound } from '../game/audio.ts';
import {
  SUMMON_BANNERS,
  CHARACTERS_DATABASE,
  createPlayerCharacter,
} from '../game/database.ts';

interface SummonViewProps {
  inventory: PlayerInventory;
  unlockedCharacters: PlayerCharacter[];
  pityCounts: Record<string, number>;
  summonHistory: Array<{
    characterId: string;
    characterName: string;
    rarity: string;
    timestamp: number;
    bannerName: string;
  }>;
  onUpdateInventory: (newInv: PlayerInventory) => void;
  onAddCharacters: (newHeroes: PlayerCharacter[]) => void;
  onUpdatePity: (bannerId: string, count: number) => void;
  onAddHistory: (entries: Array<{
    characterId: string;
    characterName: string;
    rarity: string;
    timestamp: number;
    bannerName: string;
  }>) => void;
}

export const SummonView: React.FC<SummonViewProps> = ({
  inventory,
  unlockedCharacters,
  pityCounts,
  summonHistory,
  onUpdateInventory,
  onAddCharacters,
  onUpdatePity,
  onAddHistory,
}) => {
  const [activeBannerIndex, setActiveBannerIndex] = useState(0);
  const [showRatesModal, setShowRatesModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  // Summon animation state
  const [summonPhase, setSummonPhase] = useState<'idle' | 'portal' | 'reveal'>('idle');
  const [pulledResults, setPulledResults] = useState<
    Array<{
      character: PlayerCharacter;
      isNew: boolean;
      shardsGained: number;
      rarity: Rarity;
    }>
  >([]);

  const banner = SUMMON_BANNERS[activeBannerIndex];
  const currentPity = pityCounts[banner.id] || 0;

  // Build pool for gacha
  const gachaPool = {
    UR: CHARACTERS_DATABASE.filter((c) => c.rarity === 'UR').map((c) => c.id),
    SSR: CHARACTERS_DATABASE.filter((c) => c.rarity === 'SSR').map((c) => c.id),
    SR: CHARACTERS_DATABASE.filter((c) => c.rarity === 'SR').map((c) => c.id),
    R: CHARACTERS_DATABASE.filter((c) => c.rarity === 'R').map((c) => c.id),
  };

  // If pool has empty R, fallback to SR
  if (gachaPool.R.length === 0) {
    gachaPool.R = gachaPool.SR;
  }

  // Handle summon pull
  const handleSummon = (count: 1 | 10) => {
    const costGems = count === 1 ? banner.costSingle : banner.costMulti;
    const canUseTicket = count === 1 && inventory.summonTickets >= 1;
    const canUse10Tickets = count === 10 && inventory.summonTickets >= 10;

    if (!canUseTicket && !canUse10Tickets && inventory.nexusGems < costGems) {
      sound.playHit();
      return;
    }

    // Deduct cost
    const nextInv = { ...inventory };
    if (count === 1 && canUseTicket) {
      nextInv.summonTickets -= 1;
    } else if (count === 10 && canUse10Tickets) {
      nextInv.summonTickets -= 10;
    } else {
      nextInv.nexusGems -= costGems;
    }
    onUpdateInventory(nextInv);

    sound.playSummonPull();
    setSummonPhase('portal');

    // Perform rolls
    let newPity = currentPity;
    const results: Array<{
      character: PlayerCharacter;
      isNew: boolean;
      shardsGained: number;
      rarity: Rarity;
    }> = [];
    const historyEntries: Array<{
      characterId: string;
      characterName: string;
      rarity: string;
      timestamp: number;
      bannerName: string;
    }> = [];

    let hasUR = false;
    let hasSSR = false;

    for (let i = 0; i < count; i++) {
      const isGuaranteedSR = count === 10 && i === 9; // Last pull guaranteed SR+
      const roll = rollGachaSingle(gachaPool, newPity, isGuaranteedSR);

      if (roll.rarity === 'UR') {
        hasUR = true;
        newPity = 0; // Reset pity on UR
      } else if (roll.rarity === 'SSR') {
        hasSSR = true;
        newPity = 0; // Reset pity on SSR
      } else {
        newPity += 1;
      }

      // Check if character already unlocked
      const existing = unlockedCharacters.find((c) => c.id === roll.characterId);
      const baseData =
        CHARACTERS_DATABASE.find((c) => c.id === roll.characterId) ||
        CHARACTERS_DATABASE[0];

      const isNew = !existing;
      let shardsGained = 0;

      if (!isNew) {
        // Convert duplicates to evolution shards
        shardsGained =
          roll.rarity === 'UR'
            ? 50
            : roll.rarity === 'SSR'
            ? 30
            : roll.rarity === 'SR'
            ? 15
            : 5;
      }

      const charInstance = existing
        ? { ...existing, shards: existing.shards + shardsGained }
        : createPlayerCharacter(roll.characterId, 1, 1);

      results.push({
        character: charInstance,
        isNew,
        shardsGained,
        rarity: roll.rarity,
      });

      historyEntries.push({
        characterId: roll.characterId,
        characterName: baseData.name,
        rarity: roll.rarity,
        timestamp: Date.now(),
        bannerName: banner.name,
      });
    }

    onUpdatePity(banner.id, newPity);
    onAddHistory(historyEntries);

    // Update character roster
    const updatedRoster = [...unlockedCharacters];
    for (const r of results) {
      const idx = updatedRoster.findIndex((c) => c.id === r.character.id);
      if (idx !== -1) {
        updatedRoster[idx] = r.character;
      } else {
        updatedRoster.push(r.character);
      }
    }
    onAddCharacters(updatedRoster);

    // Transition after portal vortex animation
    setTimeout(() => {
      setSummonPhase('reveal');
      setPulledResults(results);
      sound.playSummonReveal(hasUR);
      if (hasUR || hasSSR) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.5 },
        });
      }
    }, 1200);
  };

  return (
    <div className="relative w-full h-full flex flex-col justify-between p-3 sm:p-6 text-white overflow-y-auto">
      {/* Banner Selector Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {SUMMON_BANNERS.map((b, idx) => {
          const isActive = activeBannerIndex === idx;
          return (
            <button
              key={b.id}
              onClick={() => {
                sound.playClick();
                setActiveBannerIndex(idx);
              }}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-title tracking-wide transition flex-shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-amber-500 to-orange-600 text-slate-950 shadow-lg border border-amber-300 scale-105'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-white/10'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{b.name}</span>
            </button>
          );
        })}
      </div>

      {/* Main Banner Showcase Card */}
      <div className="relative w-full my-auto rounded-3xl overflow-hidden border-2 border-purple-500/40 shadow-[0_0_30px_rgba(168,85,247,0.3)] bg-slate-950 flex flex-col md:flex-row items-center justify-between min-h-[340px]">
        {/* Banner Art Background */}
        <div
          className="absolute inset-0 bg-cover bg-center brightness-75 scale-105"
          style={{ backgroundImage: `url(${banner.bannerImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-purple-950/70 to-black/85" />

        {/* Left: Banner Info & Lore */}
        <div className="relative z-10 p-6 sm:p-8 flex flex-col max-w-xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 bg-amber-500 text-slate-950 font-black text-xs rounded-full uppercase tracking-wider font-title">
              Banner Destacado
            </span>
            <span className="text-xs text-cyan-300 font-mono">
              Pity: {currentPity} / {banner.pityThreshold}
            </span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-black font-title text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-300 to-purple-300">
            {banner.name}
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 mt-2 font-medium leading-relaxed">
            {banner.description}
          </p>

          {/* Quick Rates clue */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-purple-400/30 text-[11px] text-purple-300 font-bold">
              UR: 1.5%
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-amber-400/30 text-[11px] text-amber-300 font-bold">
              SSR: 4.5%
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-black/60 border border-blue-400/30 text-[11px] text-blue-300 font-bold">
              SR: 24.0%
            </span>
            <button
              onClick={() => {
                sound.playClick();
                setShowRatesModal(true);
              }}
              className="text-xs text-cyan-300 hover:text-cyan-200 underline ml-2 flex items-center gap-1 cursor-pointer"
            >
              <Info className="w-3.5 h-3.5" />
              <span>Ver Probabilidades</span>
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setShowHistoryModal(true);
              }}
              className="text-xs text-slate-400 hover:text-slate-200 underline ml-2 flex items-center gap-1 cursor-pointer"
            >
              <History className="w-3.5 h-3.5" />
              <span>Historial</span>
            </button>
          </div>
        </div>

        {/* Right: Summon Action CTA Buttons */}
        <div className="relative z-10 p-6 flex flex-col sm:flex-row md:flex-col gap-3 w-full md:w-auto items-center justify-center">
          {/* 1x Summon */}
          <button
            onClick={() => handleSummon(1)}
            className="w-full sm:w-56 py-3.5 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-500 hover:to-indigo-600 text-white font-extrabold text-sm font-title shadow-lg border border-blue-400/40 transition active:scale-95 cursor-pointer flex flex-col items-center justify-center gap-0.5"
          >
            <span>Invocación x1</span>
            <div className="flex items-center gap-1.5 text-xs text-cyan-200 font-normal">
              {inventory.summonTickets >= 1 ? (
                <span className="flex items-center gap-1">
                  <Ticket className="w-3.5 h-3.5 text-emerald-300" /> 1 Ticket
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-300" /> {banner.costSingle} Gemas
                </span>
              )}
            </div>
          </button>

          {/* 10x Summon */}
          <button
            onClick={() => handleSummon(10)}
            className="w-full sm:w-56 py-4 px-6 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-base font-title shadow-[0_0_20px_rgba(245,158,11,0.6)] border-2 border-amber-300 transition active:scale-95 cursor-pointer flex flex-col items-center justify-center gap-0.5"
          >
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 fill-slate-950" />
              <span>Invocación x10</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-900 font-bold">
              {inventory.summonTickets >= 10 ? (
                <span className="flex items-center gap-1">
                  <Ticket className="w-3.5 h-3.5" /> 10 Tickets
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  {banner.costMulti} Gemas (10% Dcto)
                </span>
              )}
            </div>
          </button>
        </div>
      </div>

      {/* FULLSCREEN SUMMON PORTAL ANIMATION */}
      {summonPhase === 'portal' && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/95 backdrop-blur-xl animate-fadeIn">
          <div className="relative flex items-center justify-center">
            {/* Spinning dimensional vortex rings */}
            <div className="w-64 h-64 sm:w-80 sm:h-80 rounded-full border-4 border-dashed border-amber-400/80 animate-spin" />
            <div className="absolute w-48 h-48 sm:w-60 sm:h-60 rounded-full border-4 border-dashed border-cyan-400/80 animate-spin" style={{ animationDirection: 'reverse' }} />
            <div className="absolute w-32 h-32 sm:w-40 sm:h-40 rounded-full bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 blur-xl animate-pulse" />
            <Sparkles className="absolute w-16 h-16 text-white animate-bounce" />
          </div>
          <h3 className="text-2xl sm:text-3xl font-black font-title text-amber-300 mt-8 tracking-wider uppercase animate-pulse">
            Abriendo Grieta del Nexo...
          </h3>
          <p className="text-xs sm:text-sm text-cyan-200 mt-1">
            Resonando con el Ki, el Chakra y la Magia Dimensional
          </p>
        </div>
      )}

      {/* FULLSCREEN SUMMON REVEAL RESULTS */}
      {summonPhase === 'reveal' && (
        <div className="fixed inset-0 z-[100] flex flex-col items-center justify-between bg-black/95 backdrop-blur-xl p-4 sm:p-6 animate-fadeIn overflow-y-auto">
          <div className="w-full max-w-5xl flex items-center justify-between pb-3 border-b border-purple-500/30">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-amber-400" />
              <h3 className="text-xl sm:text-2xl font-black font-title text-amber-300 uppercase tracking-wide">
                Resultados de Invocación
              </h3>
            </div>
            <button
              onClick={() => setSummonPhase('idle')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase cursor-pointer"
            >
              Cerrar
            </button>
          </div>

          {/* Cards Grid */}
          <div className="w-full max-w-5xl grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4 my-auto py-6">
            {pulledResults.map((item, idx) => {
              const isHighTier = item.rarity === 'UR' || item.rarity === 'SSR';

              return (
                <div
                  key={idx}
                  className={`relative rounded-2xl p-3 flex flex-col items-center text-center transition-transform hover:scale-105 ${
                    item.rarity === 'UR'
                      ? 'bg-gradient-to-b from-purple-950 via-slate-900 to-black border-2 border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.6)] animate-pulse-glow'
                      : item.rarity === 'SSR'
                      ? 'bg-gradient-to-b from-amber-950/80 via-slate-900 to-black border-2 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.4)]'
                      : 'bg-slate-900/80 border border-slate-700'
                  }`}
                >
                  {/* New / Dupe badge */}
                  {item.isNew ? (
                    <span className="absolute -top-2 left-2 bg-emerald-500 text-slate-950 text-[10px] font-black px-2 py-0.5 rounded-full font-title uppercase shadow">
                      ¡Nuevo!
                    </span>
                  ) : (
                    <span className="absolute -top-2 left-2 bg-blue-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full font-title uppercase shadow">
                      +{item.shardsGained} Shards
                    </span>
                  )}

                  {/* Rarity */}
                  <span
                    className={`absolute -top-2 right-2 text-[10px] font-black px-2 py-0.5 rounded-full font-title ${
                      item.rarity === 'UR'
                        ? 'bg-purple-600 text-white border border-amber-300'
                        : item.rarity === 'SSR'
                        ? 'bg-amber-500 text-slate-950'
                        : 'bg-slate-700 text-slate-200'
                    }`}
                  >
                    {item.rarity}
                  </span>

                  <img
                    src={item.character.avatar}
                    alt={item.character.name}
                    className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border border-white/20 my-2 shadow-md"
                  />

                  <h4 className="text-xs sm:text-sm font-bold font-title text-white truncate w-full">
                    {item.character.name}
                  </h4>
                  <span className="text-[10px] text-slate-400 truncate w-full">
                    {item.character.title}
                  </span>

                  {item.shardsGained > 0 && (
                    <span className="text-[10px] text-amber-300 font-mono mt-1">
                      Fragmentos para Estrellas
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          <div className="w-full max-w-sm">
            <button
              onClick={() => setSummonPhase('idle')}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-sm uppercase font-title tracking-wider shadow-lg transition active:scale-95 cursor-pointer"
            >
              Continuar
            </button>
          </div>
        </div>
      )}

      {/* RATES MODAL */}
      {showRatesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-purple-500/40 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-lg font-black font-title text-amber-300 uppercase">
                Probabilidades de Invocación
              </h3>
              <button
                onClick={() => setShowRatesModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 my-4">
              <div className="flex justify-between items-center p-2.5 bg-purple-950/40 border border-purple-500/30 rounded-xl">
                <span className="font-bold text-sm text-purple-300 font-title">Ultra Raro (UR)</span>
                <span className="font-mono text-sm font-bold text-white">1.50%</span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-amber-950/40 border border-amber-500/30 rounded-xl">
                <span className="font-bold text-sm text-amber-300 font-title">Súper Súper Raro (SSR)</span>
                <span className="font-mono text-sm font-bold text-white">4.50%</span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-blue-950/40 border border-blue-500/30 rounded-xl">
                <span className="font-bold text-sm text-blue-300 font-title">Súper Raro (SR)</span>
                <span className="font-mono text-sm font-bold text-white">24.00%</span>
              </div>
              <div className="flex justify-between items-center p-2.5 bg-slate-950/60 border border-slate-700 rounded-xl">
                <span className="font-bold text-sm text-slate-300 font-title">Raro (R)</span>
                <span className="font-mono text-sm font-bold text-white">70.00%</span>
              </div>
            </div>

            <div className="bg-black/40 p-3 rounded-xl border border-white/10 text-xs text-slate-300 leading-relaxed">
              <p className="font-bold text-amber-400 mb-1">Garantía / Sistema de Pity:</p>
              • Invocación x10 garantiza al menos 1 personaje de grado SR o superior.
              <br />• Si alcanzas 50 tiradas sin un SSR, el siguiente está asegurado al 100%.
              <br />• Al alcanzar 80 tiradas, se garantiza un héroe UR definitivo.
            </div>

            <button
              onClick={() => setShowRatesModal(false)}
              className="w-full mt-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase cursor-pointer"
            >
              Entendido
            </button>
          </div>
        </div>
      )}

      {/* HISTORY MODAL */}
      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-purple-500/40 rounded-3xl p-6 max-w-lg w-full max-h-[80vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-lg font-black font-title text-amber-300 uppercase flex items-center gap-2">
                <History className="w-5 h-5" />
                <span>Historial de Invocaciones</span>
              </h3>
              <button
                onClick={() => setShowHistoryModal(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 my-4 pr-1">
              {summonHistory.length === 0 ? (
                <div className="text-center py-12 text-sm text-slate-400">
                  Aún no has realizado invocaciones en este dispositivo.
                </div>
              ) : (
                summonHistory
                  .slice()
                  .reverse()
                  .map((entry, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-black/50 border border-white/5"
                    >
                      <div className="flex flex-col">
                        <span className="font-bold text-xs text-white">
                          {entry.characterName}
                        </span>
                        <span className="text-[10px] text-slate-400">{entry.bannerName}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs font-black font-title px-2 py-0.5 rounded ${
                            entry.rarity === 'UR'
                              ? 'bg-purple-600 text-white'
                              : entry.rarity === 'SSR'
                              ? 'bg-amber-500 text-slate-950'
                              : 'bg-slate-700 text-slate-300'
                          }`}
                        >
                          {entry.rarity}
                        </span>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {new Date(entry.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                    </div>
                  ))
              )}
            </div>

            <button
              onClick={() => setShowHistoryModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs uppercase cursor-pointer"
            >
              Cerrar Historial
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
