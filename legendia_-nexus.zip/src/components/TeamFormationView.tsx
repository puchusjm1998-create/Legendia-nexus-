/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Users,
  Shield,
  Zap,
  Swords,
  Sparkles,
  CheckCircle,
  Plus,
  RefreshCw,
  Star,
} from 'lucide-react';
import type { PlayerCharacter, Universe } from '../game/types.ts';
import { calculateTeamSynergies } from '../game/rules.ts';
import { sound } from '../game/audio.ts';

interface TeamFormationViewProps {
  characters: PlayerCharacter[];
  activeTeamIds: string[];
  onUpdateTeam: (newTeamIds: string[]) => void;
}

export const TeamFormationView: React.FC<TeamFormationViewProps> = ({
  characters,
  activeTeamIds,
  onUpdateTeam,
}) => {
  const [selectedSlotIndex, setSelectedSlotIndex] = useState<number | null>(null);

  // Active heroes
  const activeHeroes = activeTeamIds
    .map((id) => characters.find((c) => c.id === id))
    .filter(Boolean) as PlayerCharacter[];

  // Synergies calculation
  const universesInTeam = activeHeroes.map((h) => h.universe);
  const synergies = calculateTeamSynergies(universesInTeam);

  // Total Team Power (CP)
  const totalPower = activeHeroes.reduce((acc, h) => {
    return acc + Math.round(h.currentHp * 0.2 + h.currentAtk * 1.5 + h.currentDef * 1.2 + h.currentSpd * 5);
  }, 0);

  // Swap hero into slot
  const handleAssignHero = (heroId: string) => {
    sound.playClick();
    if (selectedSlotIndex === null) return;

    let nextTeam = [...activeTeamIds];
    const existingIdx = nextTeam.indexOf(heroId);

    if (existingIdx !== -1) {
      const currentAtTarget = nextTeam[selectedSlotIndex];
      if (currentAtTarget) {
        nextTeam[existingIdx] = currentAtTarget;
      } else {
        nextTeam = nextTeam.filter((id) => id !== heroId);
      }
    }

    nextTeam[selectedSlotIndex] = heroId;

    // Filter out undefined and ensure non-empty
    const cleaned = nextTeam.filter(Boolean);
    onUpdateTeam(cleaned);
    setSelectedSlotIndex(null);
  };

  return (
    <div className="w-full h-full flex flex-col p-3 sm:p-6 text-white overflow-y-auto">
      {/* Header with Power and Synergies */}
      <div className="flex flex-col md:flex-row items-center justify-between pb-4 border-b border-purple-500/20 mb-6 gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-gradient-to-tr from-amber-500/20 to-purple-600/20 border border-amber-400/40">
            <Users className="w-6 h-6 text-amber-400" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-black font-title uppercase tracking-wide text-amber-300">
              Formación de Escuadrón (4 Héroes)
            </h2>
            <p className="text-xs text-slate-300">
              Combina guerreros de los 3 universos para desatar la Convergencia del Nexo.
            </p>
          </div>
        </div>

        {/* Combat Power */}
        <div className="flex items-center gap-2 bg-black/60 px-4 py-2 rounded-2xl border border-amber-400/50 shadow-inner">
          <Swords className="w-5 h-5 text-amber-400" />
          <div className="flex flex-col">
            <span className="text-[10px] text-slate-400 uppercase font-bold">Poder de Escuadrón</span>
            <span className="text-lg font-black font-title text-amber-300 tabular-nums">
              {totalPower.toLocaleString()} CP
            </span>
          </div>
        </div>
      </div>

      {/* Synergies Active Banner */}
      <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-blue-950/60 border border-purple-500/30 flex flex-col gap-2">
        <div className="flex items-center gap-2 text-xs font-black font-title uppercase text-cyan-300">
          <Sparkles className="w-4 h-4 fill-cyan-400" />
          <span>Sinergias Multiverso Activas:</span>
        </div>

        {synergies.descriptions.length === 0 ? (
          <p className="text-xs text-slate-400">
            Añade más personajes del mismo universo o combina los tres para activar bonificaciones de equipo.
          </p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {synergies.descriptions.map((desc, i) => (
              <span
                key={i}
                className="px-3 py-1 rounded-full text-xs font-bold bg-purple-900/60 text-purple-200 border border-purple-400/50 flex items-center gap-1.5"
              >
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>{desc}</span>
              </span>
            ))}
          </div>
        )}
      </div>

      {/* 4 ACTIVE HERO SLOTS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mb-8">
        {[0, 1, 2, 3].map((slotIdx) => {
          const heroId = activeTeamIds[slotIdx];
          const hero = characters.find((c) => c.id === heroId);
          const isSelectedSlot = selectedSlotIndex === slotIdx;

          return (
            <div
              key={slotIdx}
              onClick={() => {
                sound.playClick();
                setSelectedSlotIndex(isSelectedSlot ? null : slotIdx);
              }}
              className={`relative rounded-3xl p-4 flex flex-col items-center text-center transition-all cursor-pointer ${
                isSelectedSlot
                  ? 'bg-purple-900/80 border-2 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.6)] scale-105'
                  : hero
                  ? 'bg-slate-900/80 hover:bg-slate-800 border border-purple-500/30'
                  : 'bg-slate-950/60 border-2 border-dashed border-slate-700 hover:border-slate-500'
              }`}
            >
              <span className="absolute top-2 left-3 text-[10px] font-black uppercase text-slate-400 font-title">
                Posición {slotIdx + 1}
              </span>

              {hero ? (
                <>
                  <div className="relative my-3">
                    <img
                      src={hero.avatar}
                      alt={hero.name}
                      className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
                    />
                    <span className="absolute -bottom-2 right-0 bg-purple-700 text-[10px] font-black px-1.5 rounded-full font-title text-white">
                      {hero.rarity}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold font-title text-white truncate w-full">
                    {hero.name}
                  </h4>
                  <span className="text-[11px] text-amber-300 font-mono">
                    Nv.{hero.level} · {hero.stars} Estrellas
                  </span>

                  <span className="mt-2 text-[10px] text-cyan-300 uppercase font-bold tracking-wider">
                    {hero.universe.replace('_', ' ')}
                  </span>
                </>
              ) : (
                <div className="py-10 flex flex-col items-center justify-center text-slate-500">
                  <Plus className="w-8 h-8 mb-1" />
                  <span className="text-xs font-bold uppercase font-title">Asignar Héroe</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* BENCH HERO PICKER (When a slot is selected) */}
      {selectedSlotIndex !== null && (
        <div className="p-4 rounded-3xl bg-black/80 border border-cyan-400/40 animate-fadeIn">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
            <h4 className="text-sm font-bold font-title text-cyan-300 uppercase">
              Selecciona un héroe para la Posición {selectedSlotIndex + 1}:
            </h4>
            <button
              onClick={() => setSelectedSlotIndex(null)}
              className="text-xs text-slate-400 hover:text-white cursor-pointer"
            >
              Cancelar
            </button>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-6 md:grid-cols-8 gap-2.5 max-h-60 overflow-y-auto">
            {characters.map((hero) => {
              const isInCurrentTeam = activeTeamIds.includes(hero.id);

              return (
                <div
                  key={hero.id}
                  onClick={() => handleAssignHero(hero.id)}
                  className={`p-2 rounded-xl flex flex-col items-center text-center cursor-pointer transition ${
                    isInCurrentTeam
                      ? 'bg-purple-950/40 border border-purple-500/50'
                      : 'bg-slate-900 hover:bg-slate-800 border border-white/10'
                  }`}
                >
                  <img
                    src={hero.avatar}
                    alt={hero.name}
                    className="w-12 h-12 rounded-lg object-cover mb-1"
                  />
                  <span className="text-[10px] font-bold text-white truncate w-full">
                    {hero.name.split(' ')[0]}
                  </span>
                  <span className="text-[9px] text-amber-300 font-mono flex items-center justify-center gap-0.5">
                    <Star className="w-2.5 h-2.5 fill-amber-300" />
                    <span>{hero.stars}</span>
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
