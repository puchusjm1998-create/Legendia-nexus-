/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import {
  Star,
  Zap,
  Shield,
  Heart,
  Flame,
  Droplets,
  Wind,
  Sun,
  Moon,
  Sparkles,
  ArrowUpCircle,
  Coins,
  Check,
  X,
  Swords,
} from 'lucide-react';
import type {
  PlayerCharacter,
  PlayerInventory,
  Universe,
  Element,
} from '../game/types.ts';
import { calculateStarMultiplier, calculateExpForLevel } from '../game/rules.ts';
import { sound } from '../game/audio.ts';

interface HeroesViewProps {
  characters: PlayerCharacter[];
  inventory: PlayerInventory;
  onUpdateCharacter: (char: PlayerCharacter) => void;
  onUpdateInventory: (inv: PlayerInventory) => void;
}

export const HeroesView: React.FC<HeroesViewProps> = ({
  characters,
  inventory,
  onUpdateCharacter,
  onUpdateInventory,
}) => {
  const [universeFilter, setUniverseFilter] = useState<'all' | Universe>('all');
  const [selectedHeroId, setSelectedHeroId] = useState<string>(characters[0]?.id || '');

  const filtered = characters.filter((c) => {
    if (universeFilter === 'all') return true;
    return c.universe === universeFilter;
  });

  const selectedHero = characters.find((c) => c.id === selectedHeroId) || characters[0];

  // Star evolution costs based on current stars
  const getStarCost = (currentStars: number) => {
    const nextStar = currentStars + 1;
    if (nextStar > 14) return null;

    let shardsCost = 20;
    let crystalsCost = 5;
    let goldCost = 5000;

    if (nextStar > 5 && nextStar <= 10) {
      // Red Star Awakening
      shardsCost = 40 + (nextStar - 5) * 10;
      crystalsCost = 15 + (nextStar - 5) * 5;
      goldCost = 15000 + (nextStar - 5) * 5000;
    } else if (nextStar > 10) {
      // Rainbow Transcendence
      shardsCost = 100 + (nextStar - 10) * 25;
      crystalsCost = 40 + (nextStar - 10) * 15;
      goldCost = 50000 + (nextStar - 10) * 20000;
    }

    return { shardsCost, crystalsCost, goldCost };
  };

  const starCost = selectedHero ? getStarCost(selectedHero.stars) : null;

  // Level up costs
  const levelUpCost = selectedHero
    ? {
        expOrbs: Math.max(1, Math.floor(selectedHero.level * 2)),
        gold: Math.max(100, selectedHero.level * 350),
      }
    : null;

  // Handle Level Up
  const handleLevelUp = () => {
    if (!selectedHero || !levelUpCost) return;

    if (inventory.expOrbs < levelUpCost.expOrbs || inventory.gold < levelUpCost.gold) {
      sound.playHit();
      return;
    }

    // Deduct items
    const nextInv = {
      ...inventory,
      expOrbs: inventory.expOrbs - levelUpCost.expOrbs,
      gold: inventory.gold - levelUpCost.gold,
    };
    onUpdateInventory(nextInv);

    sound.playSummonReveal();

    const newLevel = selectedHero.level + 1;
    const starMult = calculateStarMultiplier(selectedHero.stars);
    const hp = Math.round(selectedHero.baseHp * (1 + (newLevel - 1) * 0.12) * starMult);
    const atk = Math.round(selectedHero.baseAtk * (1 + (newLevel - 1) * 0.12) * starMult);
    const def = Math.round(selectedHero.baseDef * (1 + (newLevel - 1) * 0.12) * starMult);

    const updatedHero: PlayerCharacter = {
      ...selectedHero,
      level: newLevel,
      maxHp: hp,
      currentHp: hp,
      currentAtk: atk,
      currentDef: def,
      maxExp: calculateExpForLevel(newLevel),
    };

    onUpdateCharacter(updatedHero);
  };

  // Handle Star Awakening (up to 14 stars)
  const handleStarAwaken = () => {
    if (!selectedHero || !starCost) return;

    if (
      selectedHero.shards < starCost.shardsCost ||
      inventory.starCrystals < starCost.crystalsCost ||
      inventory.gold < starCost.goldCost
    ) {
      sound.playHit();
      return;
    }

    // Deduct resources
    const nextInv = {
      ...inventory,
      starCrystals: inventory.starCrystals - starCost.crystalsCost,
      gold: inventory.gold - starCost.goldCost,
    };
    onUpdateInventory(nextInv);

    const nextStars = selectedHero.stars + 1;
    const starMult = calculateStarMultiplier(nextStars);
    const hp = Math.round(selectedHero.baseHp * (1 + (selectedHero.level - 1) * 0.12) * starMult);
    const atk = Math.round(selectedHero.baseAtk * (1 + (selectedHero.level - 1) * 0.12) * starMult);
    const def = Math.round(selectedHero.baseDef * (1 + (selectedHero.level - 1) * 0.12) * starMult);

    sound.playUltimate();
    confetti({
      particleCount: 70,
      spread: 70,
      origin: { y: 0.6 },
    });

    const updatedHero: PlayerCharacter = {
      ...selectedHero,
      stars: nextStars,
      shards: selectedHero.shards - starCost.shardsCost,
      maxHp: hp,
      currentHp: hp,
      currentAtk: atk,
      currentDef: def,
    };

    onUpdateCharacter(updatedHero);
  };

  // Render 14 stars visual representation
  const renderStarCluster = (starsCount: number) => {
    return (
      <div className="flex flex-wrap items-center gap-1">
        {Array.from({ length: 14 }).map((_, i) => {
          const isFilled = i < starsCount;
          let starColor = 'text-slate-700';

          if (isFilled) {
            if (i < 5) {
              starColor = 'text-amber-400 fill-amber-400'; // Gold Star
            } else if (i < 10) {
              starColor = 'text-red-500 fill-red-500 drop-shadow-[0_0_6px_rgba(239,68,68,0.8)]'; // Red Star
            } else {
              starColor = 'text-cyan-300 fill-cyan-300 drop-shadow-[0_0_8px_rgba(6,182,212,0.9)]'; // Rainbow/Nexus Star
            }
          }

          return (
            <Star
              key={i}
              className={`w-3.5 h-3.5 transition-transform ${starColor} ${
                isFilled ? 'scale-110' : 'opacity-40'
              }`}
            />
          );
        })}
      </div>
    );
  };

  return (
    <div className="w-full h-full flex flex-col p-3 sm:p-6 text-white overflow-y-auto">
      {/* Top Universe Filter Tabs */}
      <div className="flex items-center justify-between pb-3 border-b border-purple-500/20 mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase font-extrabold tracking-widest text-slate-400 font-title mr-2">
            Universo:
          </span>
          <button
            onClick={() => setUniverseFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              universeFilter === 'all'
                ? 'bg-purple-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Todos ({characters.length})
          </button>
          <button
            onClick={() => setUniverseFilter('dragon_ball')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              universeFilter === 'dragon_ball'
                ? 'bg-amber-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Dragon Ball
          </button>
          <button
            onClick={() => setUniverseFilter('naruto')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              universeFilter === 'naruto'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Naruto
          </button>
          <button
            onClick={() => setUniverseFilter('final_fantasy')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
              universeFilter === 'final_fantasy'
                ? 'bg-teal-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Final Fantasy
          </button>
        </div>

        {/* Inventory resources summary */}
        <div className="flex items-center gap-3 text-xs">
          <span className="flex items-center gap-1 text-cyan-300">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Orbes EXP: {inventory.expOrbs}</span>
          </span>
          <span className="flex items-center gap-1 text-amber-300">
            <Star className="w-3.5 h-3.5 fill-amber-300" />
            <span>Cristales Estelares: {inventory.starCrystals}</span>
          </span>
        </div>
      </div>

      {/* Main Container: Hero Grid (Left) + Detailed Sheet (Right) */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* HERO SELECTOR GRID (5 cols on large screens) */}
        <div className="lg:col-span-5 grid grid-cols-3 sm:grid-cols-4 gap-2.5 max-h-[580px] overflow-y-auto pr-1">
          {filtered.map((hero) => {
            const isSelected = hero.id === selectedHeroId;

            return (
              <div
                key={hero.id}
                onClick={() => {
                  sound.playClick();
                  setSelectedHeroId(hero.id);
                }}
                className={`relative rounded-2xl p-2 flex flex-col items-center text-center transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-b from-purple-900/90 to-slate-900 border-2 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.5)] scale-105'
                    : 'bg-slate-900/60 hover:bg-slate-800/80 border border-white/10'
                }`}
              >
                {/* Rarity badge */}
                <span className="absolute top-1 right-1 text-[9px] font-black px-1.5 rounded font-title bg-purple-700 text-white">
                  {hero.rarity}
                </span>

                <img
                  src={hero.avatar}
                  alt={hero.name}
                  className="w-16 h-16 sm:w-18 sm:h-18 rounded-xl object-cover border border-white/20 mt-1 shadow"
                />

                <span className="text-[11px] font-bold text-white font-title truncate w-full mt-1.5">
                  {hero.name}
                </span>

                <div className="flex items-center gap-1 text-[10px] text-amber-300 mt-0.5">
                  <Star className="w-2.5 h-2.5 fill-amber-300" />
                  <span>{hero.stars}</span>
                  <span className="text-slate-400">· Nv.{hero.level}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* DETAILED HERO SHEET & 14-STAR UPGRADE (7 cols on large screens) */}
        {selectedHero && (
          <div className="lg:col-span-7 bg-slate-900/80 border border-purple-500/30 rounded-3xl p-5 sm:p-6 flex flex-col gap-5 shadow-2xl backdrop-blur-md">
            {/* Header info */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="relative">
                <img
                  src={selectedHero.avatar}
                  alt={selectedHero.name}
                  className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover border-2 border-amber-400 shadow-xl"
                />
                <span className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-amber-500 text-slate-950 font-black text-xs px-2.5 py-0.5 rounded-full font-title uppercase">
                  {selectedHero.rarity}
                </span>
              </div>

              <div className="flex-1 text-center sm:text-left">
                <div className="flex items-center justify-center sm:justify-between flex-wrap gap-2">
                  <h3 className="text-xl sm:text-2xl font-black font-title text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-300 to-purple-300">
                    {selectedHero.name}
                  </h3>
                  <span className="text-xs uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-800 text-cyan-300 border border-cyan-500/30 font-bold">
                    {selectedHero.universe.replace('_', ' ')}
                  </span>
                </div>

                <p className="text-xs text-slate-300 mt-0.5 font-medium">{selectedHero.title}</p>

                {/* 14 Stars meter */}
                <div className="mt-3 flex flex-col sm:flex-row sm:items-center gap-2">
                  <span className="text-xs font-bold text-slate-300 font-title">
                    Evolución ({selectedHero.stars}/14 Estrellas):
                  </span>
                  {renderStarCluster(selectedHero.stars)}
                </div>

                <p className="text-xs text-amber-200/90 italic mt-2">
                  "{selectedHero.quote}"
                </p>
              </div>
            </div>

            {/* Current Stats Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-black/40 p-3.5 rounded-2xl border border-white/5">
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-emerald-400" />
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 uppercase">HP Máx</span>
                  <span className="text-sm font-bold text-white tabular-nums">
                    {selectedHero.maxHp}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Swords className="w-4 h-4 text-red-400" />
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 uppercase">Ataque</span>
                  <span className="text-sm font-bold text-white tabular-nums">
                    {selectedHero.currentAtk}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-400" />
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 uppercase">Defensa</span>
                  <span className="text-sm font-bold text-white tabular-nums">
                    {selectedHero.currentDef}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <div className="flex flex-col">
                  <span className="text-[10px] text-slate-400 uppercase">Velocidad</span>
                  <span className="text-sm font-bold text-white tabular-nums">
                    {selectedHero.currentSpd}
                  </span>
                </div>
              </div>
            </div>

            {/* Upgrade & Evolution Action Tiles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* LEVEL UP */}
              <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-cyan-500/30 flex flex-col justify-between gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-title text-cyan-300 uppercase">
                    Subir Nivel (Nv.{selectedHero.level})
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Coste: {levelUpCost?.expOrbs} Orbes · {levelUpCost?.gold} Oro
                  </span>
                </div>

                <button
                  onClick={handleLevelUp}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs uppercase font-title tracking-wider shadow transition active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ArrowUpCircle className="w-4 h-4" />
                  <span>Mejorar Nivel</span>
                </button>
              </div>

              {/* STAR AWAKENING (UP TO 14 STARS) */}
              <div className="bg-slate-950/70 p-3.5 rounded-2xl border border-amber-500/30 flex flex-col justify-between gap-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold font-title text-amber-300 uppercase">
                    Despertar Estelar ({selectedHero.stars} → {selectedHero.stars + 1} Estrellas)
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Shards: {selectedHero.shards}/{starCost?.shardsCost || 'MAX'}
                  </span>
                </div>

                <button
                  onClick={handleStarAwaken}
                  disabled={!starCost}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase font-title tracking-wider shadow transition active:scale-95 disabled:opacity-40 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 fill-slate-950" />
                  <span>
                    {selectedHero.stars >= 14 ? 'Máximo Alcanzado (14 Estrellas)' : 'Despertar Estrella'}
                  </span>
                </button>
              </div>
            </div>

            {/* Skills & Ultimate preview */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 font-title">
                Habilidades & Definitiva:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                  <span className="font-bold text-white block">
                    {selectedHero.skill1.name}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {selectedHero.skill1.description}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                  <span className="font-bold text-white block">
                    {selectedHero.skill2.name}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {selectedHero.skill2.description}
                  </span>
                </div>
                <div className="sm:col-span-2 p-2.5 rounded-xl bg-gradient-to-r from-purple-950/40 to-amber-950/40 border border-amber-400/30">
                  <div className="flex items-center gap-1 text-amber-300 font-bold font-title">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>DEFINITIVA: {selectedHero.ultimate.name}</span>
                  </div>
                  <span className="text-[11px] text-slate-300 mt-0.5 block">
                    {selectedHero.ultimate.description}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
