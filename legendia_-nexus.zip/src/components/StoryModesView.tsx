/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BookOpen,
  TowerControl as Tower,
  Skull,
  Calendar,
  Dumbbell,
  Play,
  Star,
  CheckCircle,
  Gift,
  Sparkles,
  Coins,
  ChevronRight,
} from 'lucide-react';
import type {
  StoryChapter,
  StoryEpisode,
  EnemyCharacter,
  PlayerCharacter,
  PlayerProfile,
  PlayerInventory,
} from '../game/types.ts';
import { sound } from '../game/audio.ts';
import {
  BOSS_OMEGA,
  ENEMY_CORRUPT_SAIYAN,
  ENEMY_CORRUPT_SHINOBI,
  ENEMY_CRYSTAL_GOLEM,
} from '../game/database.ts';

interface StoryModesViewProps {
  chapters: StoryChapter[];
  profile: PlayerProfile;
  inventory: PlayerInventory;
  activeHeroes: PlayerCharacter[];
  onStartBattle: (
    enemies: EnemyCharacter[],
    title: string,
    onSuccessRewards?: { gold: number; exp: number; gems: number; episodeId?: string }
  ) => void;
  onUpdateInventory: (inv: PlayerInventory) => void;
  onUpdateProfile: (prof: PlayerProfile) => void;
}

export const StoryModesView: React.FC<StoryModesViewProps> = ({
  chapters,
  profile,
  inventory,
  activeHeroes,
  onStartBattle,
  onUpdateInventory,
  onUpdateProfile,
}) => {
  const [activeTab, setActiveTab] = useState<'story' | 'tower' | 'boss' | 'calendar' | 'training'>('story');
  const [selectedChapterId, setSelectedChapterId] = useState<number>(1);
  const [activeDialogueEpisode, setActiveDialogueEpisode] = useState<StoryEpisode | null>(null);
  const [dialogueIndex, setDialogueIndex] = useState(0);

  const currentChapter = chapters.find((c) => c.id === selectedChapterId) || chapters[0];

  // 7-Day Rewards Definition
  const sevenDayRewards = [
    { day: 1, type: 'gems', amount: 500, label: '500 Gemas Nexo' },
    { day: 2, type: 'tickets', amount: 5, label: '5 Tickets de Invocación' },
    { day: 3, type: 'orbs', amount: 30, label: '30 Orbes de EXP' },
    { day: 4, type: 'crystals', amount: 15, label: '15 Cristales Estelares' },
    { day: 5, type: 'gold', amount: 25000, label: '25,000 Oro' },
    { day: 6, type: 'tickets', amount: 10, label: '10 Tickets de Invocación' },
    { day: 7, type: 'gems', amount: 2000, label: '¡2,000 Gemas + Héroe UR!' },
  ];

  // Claim 7-Day reward
  const handleClaimLoginDay = (day: number) => {
    if (profile.claimedLoginDays.includes(day)) return;

    sound.playSummonReveal();
    const rew = sevenDayRewards[day - 1];
    const nextInv = { ...inventory };

    if (rew.type === 'gems') nextInv.nexusGems += rew.amount;
    if (rew.type === 'tickets') nextInv.summonTickets += rew.amount;
    if (rew.type === 'orbs') nextInv.expOrbs += rew.amount;
    if (rew.type === 'crystals') nextInv.starCrystals += rew.amount;
    if (rew.type === 'gold') nextInv.gold += rew.amount;

    onUpdateInventory(nextInv);
    onUpdateProfile({
      ...profile,
      claimedLoginDays: [...profile.claimedLoginDays, day],
    });
  };

  // Start story episode with dialogue check
  const handleEpisodeClick = (ep: StoryEpisode) => {
    sound.playClick();
    if (ep.dialogueIntro && ep.dialogueIntro.length > 0) {
      setActiveDialogueEpisode(ep);
      setDialogueIndex(0);
    } else {
      launchBattleFromEpisode(ep);
    }
  };

  const launchBattleFromEpisode = (ep: StoryEpisode) => {
    const enemies = ep.enemyFormation.map((e) => ({
      ...e,
      hp: e.hp,
      maxHp: e.hp,
      nexusRage: 0,
      activeEffects: [],
      isAlive: true,
      drops: {
        gold: ep.firstClearRewards.gold,
        exp: ep.firstClearRewards.expOrbs * 100,
        gems: ep.firstClearRewards.gems,
      },
    })) as EnemyCharacter[];

    onStartBattle(enemies, ep.title, {
      gold: ep.firstClearRewards.gold,
      exp: ep.firstClearRewards.expOrbs * 100,
      gems: ep.firstClearRewards.gems,
      episodeId: ep.id,
    });
  };

  // Advance dialogue
  const handleNextDialogue = () => {
    if (!activeDialogueEpisode?.dialogueIntro) return;
    sound.playClick();

    if (dialogueIndex + 1 < activeDialogueEpisode.dialogueIntro.length) {
      setDialogueIndex((idx) => idx + 1);
    } else {
      const ep = activeDialogueEpisode;
      setActiveDialogueEpisode(null);
      launchBattleFromEpisode(ep);
    }
  };

  // Launch Dimensional Tower Floor
  const handleStartTowerFloor = () => {
    sound.playClick();
    const floor = profile.highestTowerFloor;
    const enemyScaling = 1 + floor * 0.08;

    const towerEnemies: EnemyCharacter[] = [
      {
        ...ENEMY_CORRUPT_SAIYAN,
        level: floor,
        hp: Math.round(ENEMY_CORRUPT_SAIYAN.hp * enemyScaling),
        maxHp: Math.round(ENEMY_CORRUPT_SAIYAN.hp * enemyScaling),
        atk: Math.round(ENEMY_CORRUPT_SAIYAN.atk * enemyScaling),
        isAlive: true,
        activeEffects: [],
      },
      {
        ...ENEMY_CORRUPT_SHINOBI,
        level: floor,
        hp: Math.round(ENEMY_CORRUPT_SHINOBI.hp * enemyScaling),
        maxHp: Math.round(ENEMY_CORRUPT_SHINOBI.hp * enemyScaling),
        atk: Math.round(ENEMY_CORRUPT_SHINOBI.atk * enemyScaling),
        isAlive: true,
        activeEffects: [],
      },
      {
        ...ENEMY_CRYSTAL_GOLEM,
        level: floor,
        hp: Math.round(ENEMY_CRYSTAL_GOLEM.hp * enemyScaling),
        maxHp: Math.round(ENEMY_CRYSTAL_GOLEM.hp * enemyScaling),
        atk: Math.round(ENEMY_CRYSTAL_GOLEM.atk * enemyScaling),
        isAlive: true,
        activeEffects: [],
      },
    ];

    onStartBattle(towerEnemies, `Torre Dimensional - Piso ${floor}`, {
      gold: 1500 * floor,
      exp: 2000 * floor,
      gems: 100 + floor * 20,
    });
  };

  // Launch Boss Raid: Omega Nexis
  const handleStartBossRaid = () => {
    sound.playClick();
    const bossSquad: EnemyCharacter[] = [
      {
        ...BOSS_OMEGA,
        isAlive: true,
        activeEffects: [],
      },
      {
        ...ENEMY_CRYSTAL_GOLEM,
        level: 12,
        isAlive: true,
        activeEffects: [],
      },
    ];

    onStartBattle(bossSquad, 'Incursión de Jefe: Omega Nexis', {
      gold: 10000,
      exp: 15000,
      gems: 1500,
    });
  };

  // Quick Training Session
  const handleDoTraining = (type: 'exp' | 'gold') => {
    sound.playClick();
    const enemies: EnemyCharacter[] = [
      {
        ...ENEMY_CRYSTAL_GOLEM,
        name: type === 'exp' ? 'Orbe de Entrenamiento' : 'Golem del Tesoro',
        level: 5,
        hp: 3500,
        maxHp: 3500,
        atk: 400,
        isAlive: true,
        activeEffects: [],
      },
    ];

    onStartBattle(
      enemies,
      type === 'exp' ? 'Dojo: Entrenamiento de EXP' : 'Dojo: Cámara de Oro',
      type === 'exp'
        ? { gold: 2000, exp: 6000, gems: 50 }
        : { gold: 12000, exp: 1000, gems: 50 }
    );
  };

  return (
    <div className="w-full h-full flex flex-col p-3 sm:p-6 text-white overflow-y-auto">
      {/* Modes Navigation Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 border-b border-purple-500/20 mb-6 scrollbar-none">
        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('story');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-title tracking-wide transition flex-shrink-0 cursor-pointer ${
            activeTab === 'story'
              ? 'bg-amber-500 text-slate-950 shadow-md font-black'
              : 'bg-slate-900 text-slate-300 hover:text-white'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Modo Historia</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('tower');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-title tracking-wide transition flex-shrink-0 cursor-pointer ${
            activeTab === 'tower'
              ? 'bg-cyan-500 text-slate-950 shadow-md font-black'
              : 'bg-slate-900 text-slate-300 hover:text-white'
          }`}
        >
          <Tower className="w-4 h-4" />
          <span>Torre Dimensional (Piso {profile.highestTowerFloor})</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('boss');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-title tracking-wide transition flex-shrink-0 cursor-pointer ${
            activeTab === 'boss'
              ? 'bg-red-600 text-white shadow-md font-black'
              : 'bg-slate-900 text-slate-300 hover:text-white'
          }`}
        >
          <Skull className="w-4 h-4" />
          <span>Desafío de Jefes</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('training');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-title tracking-wide transition flex-shrink-0 cursor-pointer ${
            activeTab === 'training'
              ? 'bg-emerald-600 text-white shadow-md font-black'
              : 'bg-slate-900 text-slate-300 hover:text-white'
          }`}
        >
          <Dumbbell className="w-4 h-4" />
          <span>Dojo de Recursos</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            setActiveTab('calendar');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold font-title tracking-wide transition flex-shrink-0 cursor-pointer ${
            activeTab === 'calendar'
              ? 'bg-purple-600 text-white shadow-md font-black'
              : 'bg-slate-900 text-slate-300 hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Recompensas 7 Días</span>
        </button>
      </div>

      {/* TAB 1: STORY CHAPTERS & EPISODES */}
      {activeTab === 'story' && (
        <div className="flex flex-col gap-6">
          {/* Chapter Selector */}
          <div className="flex gap-3">
            {chapters.map((chap) => (
              <button
                key={chap.id}
                onClick={() => {
                  sound.playClick();
                  setSelectedChapterId(chap.id);
                }}
                className={`flex-1 p-4 rounded-2xl border text-left transition cursor-pointer ${
                  selectedChapterId === chap.id
                    ? 'bg-gradient-to-r from-purple-950 to-slate-900 border-amber-400 shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <span className="text-[10px] uppercase font-bold text-amber-400 font-title block">
                  Capítulo {chap.id}
                </span>
                <h4 className="text-sm sm:text-base font-bold text-white font-title mt-0.5">
                  {chap.title}
                </h4>
                <p className="text-xs text-slate-400 mt-1 line-clamp-1">{chap.description}</p>
              </button>
            ))}
          </div>

          {/* Episode List */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentChapter.episodes.map((ep) => (
              <div
                key={ep.id}
                className="bg-slate-900/80 border border-purple-500/30 rounded-2xl p-4 flex flex-col justify-between gap-4 hover:border-amber-400/50 transition shadow-md"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-cyan-300 font-title uppercase">
                      Nivel Sugerido: {ep.recommendedLevel}
                    </span>
                    <div className="flex items-center gap-0.5 text-amber-400">
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                      <Star className="w-3.5 h-3.5 fill-amber-400" />
                    </div>
                  </div>

                  <h4 className="text-base font-black font-title text-white mt-1">
                    {ep.title}
                  </h4>

                  {/* Rewards preview */}
                  <div className="mt-3 flex items-center gap-2 text-xs text-slate-300 bg-black/40 p-2 rounded-xl">
                    <span className="flex items-center gap-1 text-purple-300">
                      <Sparkles className="w-3 h-3" /> {ep.firstClearRewards.gems} Gemas
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1 text-amber-300">
                      <Coins className="w-3 h-3" /> {ep.firstClearRewards.gold}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => handleEpisodeClick(ep)}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs uppercase font-title tracking-wider shadow transition active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>Comenzar Batalla</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: DIMENSIONAL TOWER */}
      {activeTab === 'tower' && (
        <div className="flex flex-col items-center max-w-xl mx-auto my-auto text-center p-6 bg-slate-900/80 border border-cyan-500/30 rounded-3xl shadow-2xl backdrop-blur-md">
          <Tower className="w-16 h-16 text-cyan-400 mb-3 animate-bounce" />
          <h3 className="text-2xl font-black font-title text-cyan-300 uppercase">
            Torre Dimensional del Nexo
          </h3>
          <p className="text-xs text-slate-300 max-w-md mt-1">
            Asciende los 50 pisos de la torre dimensional. Cada piso contiene anomalías más poderosas pero otorga gemas y materiales estelares exclusivos.
          </p>

          <div className="my-6 p-4 rounded-2xl bg-black/50 border border-white/10 w-full flex items-center justify-around">
            <div>
              <span className="text-[10px] text-slate-400 uppercase block font-bold">Piso Actual</span>
              <span className="text-2xl font-black text-amber-400 font-title">
                {profile.highestTowerFloor} / 50
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 uppercase block font-bold">Recompensa</span>
              <span className="text-sm font-bold text-purple-300">
                +{100 + profile.highestTowerFloor * 20} Gemas
              </span>
            </div>
          </div>

          <button
            onClick={handleStartTowerFloor}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black text-sm uppercase font-title tracking-wider shadow-lg transition active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Desafiar Piso {profile.highestTowerFloor}</span>
          </button>
        </div>
      )}

      {/* TAB 3: BOSS RAID */}
      {activeTab === 'boss' && (
        <div className="flex flex-col items-center max-w-xl mx-auto my-auto text-center p-6 bg-slate-900/80 border border-red-500/40 rounded-3xl shadow-2xl backdrop-blur-md">
          <Skull className="w-16 h-16 text-red-500 mb-3 animate-pulse" />
          <h3 className="text-2xl font-black font-title text-red-400 uppercase">
            Incursión: Omega Nexis
          </h3>
          <p className="text-xs text-slate-300 max-w-md mt-1">
            El dios destructor del vacío que colapsó las líneas temporales. Requiere una formación coordinada con las definitivas listas.
          </p>

          <div className="my-6 p-4 rounded-2xl bg-black/50 border border-red-500/30 w-full flex items-center justify-around text-xs">
            <div>
              <span className="text-slate-400 block font-bold">HP de Jefe</span>
              <span className="text-sm font-black text-red-400 font-mono">24,000 HP</span>
            </div>
            <div>
              <span className="text-slate-400 block font-bold">Gran Recompensa</span>
              <span className="text-sm font-black text-amber-300 font-mono">1,500 Gemas</span>
            </div>
          </div>

          <button
            onClick={handleStartBossRaid}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-purple-700 hover:from-red-500 hover:to-purple-600 text-white font-black text-sm uppercase font-title tracking-wider shadow-[0_0_25px_rgba(239,68,68,0.6)] transition active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Iniciar Incursión contra Omega Nexis</span>
          </button>
        </div>
      )}

      {/* TAB 4: TRAINING DOJO */}
      {activeTab === 'training' && (
        <div className="max-w-2xl mx-auto my-auto grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
          <div className="bg-slate-900/80 border border-cyan-500/30 rounded-3xl p-6 text-center flex flex-col justify-between">
            <div>
              <Sparkles className="w-12 h-12 text-cyan-400 mx-auto mb-2" />
              <h4 className="text-lg font-black font-title text-cyan-300 uppercase">
                Dojo de EXP
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                Entrena a tus guerreros para obtener grandes cantidades de Orbes de Experiencia.
              </p>
            </div>
            <button
              onClick={() => handleDoTraining('exp')}
              className="mt-6 py-3 rounded-2xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs uppercase font-title tracking-wider cursor-pointer"
            >
              Comenzar Entrenamiento
            </button>
          </div>

          <div className="bg-slate-900/80 border border-amber-500/30 rounded-3xl p-6 text-center flex flex-col justify-between">
            <div>
              <Coins className="w-12 h-12 text-amber-400 mx-auto mb-2" />
              <h4 className="text-lg font-black font-title text-amber-300 uppercase">
                Cámara de Oro
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                Vence al Gólem del Tesoro para reunir 12,000 monedas de oro para evoluciones.
              </p>
            </div>
            <button
              onClick={() => handleDoTraining('gold')}
              className="mt-6 py-3 rounded-2xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs uppercase font-title tracking-wider cursor-pointer"
            >
              Reclamar Oro
            </button>
          </div>
        </div>
      )}

      {/* TAB 5: 7-DAY LOGIN REWARDS */}
      {activeTab === 'calendar' && (
        <div className="max-w-4xl mx-auto my-auto w-full">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-black font-title text-amber-300 uppercase">
              Calendario de Inicio de Sesión de 7 Días
            </h3>
            <p className="text-xs text-slate-300">
              Conéctate cada día para obtener gemas, tickets y héroes legendarios.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {sevenDayRewards.map((reward) => {
              const isClaimed = profile.claimedLoginDays.includes(reward.day);

              return (
                <div
                  key={reward.day}
                  className={`rounded-2xl p-3 flex flex-col items-center text-center justify-between min-h-[140px] border transition ${
                    isClaimed
                      ? 'bg-slate-950/40 border-slate-800 opacity-60'
                      : 'bg-slate-900/90 border-purple-500/40 shadow-lg'
                  }`}
                >
                  <span className="text-[11px] font-black uppercase text-amber-400 font-title">
                    Día {reward.day}
                  </span>

                  <Gift
                    className={`w-8 h-8 my-1 ${
                      isClaimed ? 'text-slate-600' : 'text-purple-400 animate-pulse'
                    }`}
                  />

                  <span className="text-[11px] font-bold text-white leading-tight">
                    {reward.label}
                  </span>

                  <button
                    onClick={() => handleClaimLoginDay(reward.day)}
                    disabled={isClaimed}
                    className={`w-full mt-2 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-wider font-title transition cursor-pointer ${
                      isClaimed
                        ? 'bg-slate-800 text-slate-500'
                        : 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 hover:scale-105'
                    }`}
                  >
                    {isClaimed ? 'Reclamado' : 'Reclamar'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* STORY DIALOGUE CINEMATIC MODAL */}
      {activeDialogueEpisode && activeDialogueEpisode.dialogueIntro && (
        <div className="fixed inset-0 z-[100] flex flex-col justify-end bg-black/85 backdrop-blur-md p-4 sm:p-8 pb-24 sm:pb-28 animate-fadeIn">
          <div className="max-w-4xl mx-auto w-full bg-slate-950/95 border-2 border-purple-500/50 rounded-3xl p-5 sm:p-6 shadow-[0_0_35px_rgba(168,85,247,0.5)]">
            {/* Character Speaker avatar + dialogue line */}
            <div className="flex items-start gap-4">
              <img
                src={activeDialogueEpisode.dialogueIntro[dialogueIndex]?.avatar}
                alt={activeDialogueEpisode.dialogueIntro[dialogueIndex]?.speaker}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
              />
              <div className="flex-1">
                <span className="text-xs uppercase font-extrabold tracking-wider text-amber-400 font-title">
                  {activeDialogueEpisode.dialogueIntro[dialogueIndex]?.speaker}
                </span>
                <p className="text-sm sm:text-base text-white font-medium mt-1 leading-relaxed">
                  "{activeDialogueEpisode.dialogueIntro[dialogueIndex]?.text}"
                </p>
              </div>
            </div>

            <div className="mt-4 flex justify-between items-center pt-3 border-t border-white/10">
              <span className="text-xs text-slate-400 font-mono">
                {dialogueIndex + 1} / {activeDialogueEpisode.dialogueIntro.length}
              </span>
              <button
                onClick={handleNextDialogue}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-xs uppercase font-title tracking-wider shadow hover:scale-105 transition active:scale-95 flex items-center gap-1 cursor-pointer"
              >
                <span>Siguiente</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
