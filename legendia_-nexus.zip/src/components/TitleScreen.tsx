/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { Volume2, VolumeX, Smartphone, Play, Sparkles } from 'lucide-react';
import { sound } from '../game/audio.ts';
import { bgImage, appIcon } from '../game/database.ts';

interface TitleScreenProps {
  onStart: () => void;
  onOpenAndroidModal: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  onOpenAndroidModal,
  isMuted,
  onToggleMute,
}) => {
  // Listen for Enter / Space keys to start immediately
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        sound.playClick();
        onStart();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onStart]);

  return (
    <div className="relative w-full h-screen overflow-hidden flex flex-col justify-between items-center text-white bg-slate-950 select-none">
      {/* Background key-art with subtle ambient zoom */}
      <div
        className="absolute inset-0 bg-cover bg-center scale-105 transition-transform duration-10000 ease-out"
        style={{ backgroundImage: `url(${bgImage})` }}
      />

      {/* Atmospheric vignette and gradient overlays (allowing 35% negative space for text) */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/75 pointer-events-none" />
      <div className="absolute inset-0 bg-radial-gradient from-transparent via-black/20 to-black/80 pointer-events-none" />

      {/* Top Bar with Audio & Android quick controls */}
      <header className="relative z-10 w-full max-w-7xl px-6 pt-6 flex justify-between items-center">
        <div className="flex items-center gap-3 bg-black/60 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-purple-500/30">
          <img src={appIcon} alt="Logo" className="w-7 h-7 rounded-full shadow-lg border border-amber-400/50" />
          <span className="text-xs uppercase tracking-widest text-amber-300 font-bold font-title">
            Ver. 1.0.0 Oficial
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              onOpenAndroidModal();
            }}
            className="flex items-center gap-2 bg-gradient-to-r from-emerald-600/80 to-teal-700/80 hover:from-emerald-500 hover:to-teal-600 px-4 py-2 rounded-xl text-xs font-bold text-white shadow-lg border border-emerald-400/40 transition active:scale-95 cursor-pointer"
            title="Instalar en Android o compilar APK"
          >
            <Smartphone className="w-4 h-4 text-emerald-200" />
            <span className="hidden sm:inline">APK & Android</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onToggleMute();
            }}
            aria-label={isMuted ? 'Activar audio' : 'Silenciar audio'}
            className="w-10 h-10 rounded-xl bg-black/60 hover:bg-black/80 border border-white/20 flex items-center justify-center text-white/80 hover:text-white transition active:scale-95 cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-amber-400" />}
          </button>
        </div>
      </header>

      {/* Main Title Centerpiece Lockup */}
      <main className="relative z-10 flex flex-col items-center text-center max-w-3xl px-4 my-auto">
        {/* Emblem insignia */}
        <div className="relative mb-3 flex items-center justify-center">
          <div className="absolute w-28 h-28 rounded-full bg-gradient-to-tr from-amber-500/40 via-purple-600/40 to-cyan-400/40 blur-xl animate-pulse" />
          <img
            src={appIcon}
            alt="Emblema del Nexo"
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl shadow-2xl border-2 border-amber-400/80 object-cover animate-float"
          />
        </div>

        {/* Bespoke Title Lockup */}
        <div className="flex flex-col items-center">
          <span className="text-xs sm:text-sm uppercase tracking-[0.35em] text-cyan-300 font-extrabold mb-1 drop-shadow-md">
            Multiverse Anime Crossover
          </span>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black font-title uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-white via-amber-200 to-amber-500 drop-shadow-[0_4px_16px_rgba(234,179,8,0.5)]">
            LEGENDIA
          </h1>

          <div className="flex items-center gap-3 sm:gap-4 my-1">
            <div className="h-[2px] w-8 sm:w-16 bg-gradient-to-r from-transparent via-cyan-400 to-purple-500" />
            <h2 className="text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-[0.2em] font-title text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-purple-300 to-amber-300 drop-shadow-[0_2px_10px_rgba(168,85,247,0.8)]">
              NEXUS
            </h2>
            <div className="h-[2px] w-8 sm:w-16 bg-gradient-to-l from-transparent via-cyan-400 to-purple-500" />
          </div>

          <p className="text-xs sm:text-sm text-slate-300 max-w-lg mt-2 font-medium drop-shadow">
            Dragon Ball · Naruto · Final Fantasy
            <br />
            <span className="text-purple-300/90 text-[11px] sm:text-xs">
              Tres universos colisionan en la mayor batalla dimensional por turnos.
            </span>
          </p>
        </div>

        {/* Primary Start CTA */}
        <div className="mt-8 flex flex-col sm:flex-row items-center gap-4">
          <button
            data-start="true"
            onClick={() => {
              sound.playClick();
              onStart();
            }}
            className="group relative px-8 sm:px-12 py-3.5 sm:py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-slate-950 font-black text-lg sm:text-xl font-title uppercase tracking-wider shadow-[0_0_25px_rgba(245,158,11,0.6)] hover:shadow-[0_0_35px_rgba(245,158,11,0.9)] transition-all duration-200 active:scale-95 cursor-pointer flex items-center gap-3 border border-amber-300"
          >
            <Play className="w-6 h-6 fill-slate-950 text-slate-950 group-hover:scale-110 transition-transform" />
            <span>Entrar al Nexo</span>
            <Sparkles className="w-5 h-5 text-slate-900 group-hover:rotate-12 transition-transform" />
          </button>
        </div>
      </main>

      {/* Clean, Flat Control Hint Footer */}
      <footer className="relative z-10 pb-6 text-center text-xs text-slate-400/90 font-medium">
        <p className="inline-block px-4 py-1.5 rounded-full bg-black/60 backdrop-blur-sm border border-white/10">
          Espacio o Clic para Iniciar · Interfaz Táctil Android · Combate por Turnos
        </p>
      </footer>
    </div>
  );
};
