/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Coins, Ticket, Zap, Volume2, VolumeX, Smartphone, RotateCcw } from 'lucide-react';
import type { PlayerProfile, PlayerInventory } from '../game/types.ts';
import { sound } from '../game/audio.ts';
import { appIcon } from '../game/database.ts';

interface TopBarProps {
  profile: PlayerProfile;
  inventory: PlayerInventory;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenAndroidModal: () => void;
  onResetData: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  profile,
  inventory,
  isMuted,
  onToggleMute,
  onOpenAndroidModal,
  onResetData,
}) => {
  return (
    <header className="w-full bg-slate-950/85 backdrop-blur-md border-b border-purple-500/20 px-3 sm:px-6 py-2.5 flex items-center justify-between text-white z-20">
      {/* Left: Player Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        <div className="relative">
          <img
            src={appIcon}
            alt="Comandante"
            className="w-9 h-9 sm:w-11 sm:h-11 rounded-full border-2 border-amber-400 object-cover shadow-md"
          />
          <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 font-black text-[10px] sm:text-xs px-1 rounded font-title">
            {profile.level}
          </span>
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-xs sm:text-sm font-title tracking-wide text-slate-100">
              {profile.name}
            </span>
          </div>
          {/* Stamina bar */}
          <div className="flex items-center gap-1 text-[11px] text-amber-300">
            <Zap className="w-3 h-3 fill-amber-400 text-amber-400" />
            <span className="font-semibold tabular-nums">
              {profile.stamina}/{profile.maxStamina}
            </span>
          </div>
        </div>
      </div>

      {/* Center: Currencies */}
      <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto py-1">
        {/* Nexus Gems */}
        <div className="flex items-center gap-1.5 bg-purple-950/60 border border-purple-500/40 px-2.5 py-1 rounded-xl shadow-inner">
          <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
          <span className="text-xs sm:text-sm font-bold text-cyan-200 tabular-nums">
            {inventory.nexusGems.toLocaleString()}
          </span>
        </div>

        {/* Gold */}
        <div className="flex items-center gap-1.5 bg-amber-950/60 border border-amber-500/40 px-2.5 py-1 rounded-xl shadow-inner">
          <Coins className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-xs sm:text-sm font-bold text-amber-200 tabular-nums">
            {inventory.gold.toLocaleString()}
          </span>
        </div>

        {/* Summon Tickets */}
        <div className="hidden sm:flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-500/40 px-2.5 py-1 rounded-xl shadow-inner">
          <Ticket className="w-3.5 h-3.5 text-emerald-400" />
          <span className="text-xs sm:text-sm font-bold text-emerald-200 tabular-nums">
            {inventory.summonTickets}
          </span>
        </div>
      </div>

      {/* Right: Quick actions */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        <button
          onClick={() => {
            sound.playClick();
            onOpenAndroidModal();
          }}
          className="flex items-center gap-1.5 bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-400/50 text-emerald-300 px-2.5 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer"
          title="Opciones de APK e instalación Android"
        >
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span className="hidden md:inline">APK Android</span>
        </button>

        <button
          onClick={() => {
            sound.playClick();
            onToggleMute();
          }}
          aria-label={isMuted ? 'Activar audio' : 'Silenciar audio'}
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-slate-300 hover:text-white transition active:scale-95 cursor-pointer"
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
        </button>

        <button
          onClick={() => {
            sound.playClick();
            onResetData();
          }}
          aria-label="Reiniciar datos de guardado"
          className="p-1.5 sm:p-2 rounded-xl bg-slate-900 border border-slate-700 hover:border-red-500 text-slate-400 hover:text-red-400 transition active:scale-95 cursor-pointer"
          title="Reiniciar partida"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
