/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  Shield,
  Zap,
  Flame,
  Droplets,
  Wind,
  Sun,
  Moon,
  Crosshair,
  Award,
  AlertTriangle,
  RotateCcw,
  LogOut,
  Sparkles,
} from 'lucide-react';
import type {
  PlayerCharacter,
  EnemyCharacter,
  Skill,
  Element,
  Universe,
} from '../game/types.ts';
import { calculateDamage, calculateHealing, calculateTurnOrder } from '../game/rules.ts';
import { sound } from '../game/audio.ts';
import { bgImage } from '../game/database.ts';

interface BattleViewProps {
  initialHeroes: PlayerCharacter[];
  initialEnemies: EnemyCharacter[];
  battleTitle?: string;
  onVictory: (rewards: { gold: number; exp: number; gems: number }) => void;
  onDefeat: () => void;
  onExit: () => void;
}

export const BattleView: React.FC<BattleViewProps> = ({
  initialHeroes,
  initialEnemies,
  battleTitle = 'Combate Dimensional',
  onVictory,
  onDefeat,
  onExit,
}) => {
  // Deep clone combatants
  const [heroes, setHeroes] = useState<PlayerCharacter[]>(() =>
    initialHeroes.map((h) => ({
      ...h,
      currentHp: h.maxHp,
      currentEnergy: 60,
      nexusRage: 30,
      isAlive: true,
      activeEffects: [],
    }))
  );

  const [enemies, setEnemies] = useState<EnemyCharacter[]>(() =>
    initialEnemies.map((e) => ({
      ...e,
      hp: e.maxHp,
      nexusRage: 0,
      isAlive: true,
      activeEffects: [],
    }))
  );

  const [selectedEnemyIndex, setSelectedEnemyIndex] = useState<number>(0);
  const [selectedAllyIndex, setSelectedAllyIndex] = useState<number>(0);

  // Turn management
  const [turnQueue, setTurnQueue] = useState<Array<{ isHero: boolean; index: number; spd: number }>>([]);
  const [currentTurnActor, setCurrentTurnActor] = useState<{ isHero: boolean; index: number } | null>(null);
  const [battleState, setBattleState] = useState<'idle' | 'animating' | 'victory' | 'defeat'>('idle');
  const [roundNumber, setRoundNumber] = useState<number>(1);

  // Visual effects
  const [screenShake, setScreenShake] = useState(false);
  const [ultimateCutIn, setUltimateCutIn] = useState<{
    characterName: string;
    skillName: string;
    quote?: string;
    avatar: string;
    universe: Universe;
  } | null>(null);

  const [floatingNumbers, setFloatingNumbers] = useState<
    Array<{
      id: string;
      isHero: boolean;
      targetIndex: number;
      text: string;
      isCrit: boolean;
      isHeal: boolean;
    }>
  >([]);

  const [actionMessage, setActionMessage] = useState<string>('¡La batalla ha comenzado!');

  // Prevent multiple executions during timers
  const turnInProgressRef = useRef(false);

  // Calculate elemental icon
  const renderElementBadge = (elem: Element) => {
    switch (elem) {
      case 'fuego':
        return <span className="flex items-center gap-0.5 text-xs text-red-400"><Flame className="w-3.5 h-3.5 fill-red-400" /> Fuego</span>;
      case 'agua':
        return <span className="flex items-center gap-0.5 text-xs text-cyan-400"><Droplets className="w-3.5 h-3.5 fill-cyan-400" /> Agua</span>;
      case 'viento':
        return <span className="flex items-center gap-0.5 text-xs text-emerald-400"><Wind className="w-3.5 h-3.5" /> Viento</span>;
      case 'rayo':
        return <span className="flex items-center gap-0.5 text-xs text-amber-300"><Zap className="w-3.5 h-3.5 fill-amber-300" /> Rayo</span>;
      case 'luz':
        return <span className="flex items-center gap-0.5 text-xs text-yellow-200"><Sun className="w-3.5 h-3.5 fill-yellow-200" /> Luz</span>;
      case 'oscuridad':
        return <span className="flex items-center gap-0.5 text-xs text-purple-400"><Moon className="w-3.5 h-3.5 fill-purple-400" /> Oscuridad</span>;
    }
  };

  // Helper to trigger floating damage text
  const addFloatingNumber = useCallback(
    (isHero: boolean, targetIndex: number, text: string, isCrit = false, isHeal = false) => {
      const id = `${Date.now()}-${Math.random()}`;
      setFloatingNumbers((prev) => [...prev, { id, isHero, targetIndex, text, isCrit, isHeal }]);
      setTimeout(() => {
        setFloatingNumbers((prev) => prev.filter((item) => item.id !== id));
      }, 1200);
    },
    []
  );

  // Trigger camera shake
  const triggerShake = useCallback(() => {
    setScreenShake(true);
    setTimeout(() => setScreenShake(false), 250);
  }, []);

  // Recalculate turn order
  const buildTurnQueue = useCallback(() => {
    const heroEntries = heroes.map((h, i) => ({
      id: h.id,
      isHero: true,
      index: i,
      spd: h.currentSpd,
      isAlive: h.isAlive,
    }));
    const enemyEntries = enemies.map((e, i) => ({
      id: e.id,
      isHero: false,
      index: i,
      spd: e.spd,
      isAlive: e.isAlive,
    }));
    const sorted = calculateTurnOrder([...heroEntries, ...enemyEntries]);
    return sorted;
  }, [heroes, enemies]);

  // Execute an action
  const executeAction = useCallback(
    async (actorIsHero: boolean, actorIndex: number, skill: Skill) => {
      if (battleState !== 'idle' && battleState !== 'animating') return;
      turnInProgressRef.current = true;
      setBattleState('animating');

      // Check if ultimate
      if (skill.isUltimate) {
        const actor = actorIsHero ? heroes[actorIndex] : enemies[actorIndex];
        sound.playUltimate();
        setUltimateCutIn({
          characterName: actor.name,
          skillName: skill.name,
          quote: skill.quote || actor.basicAttack.quote,
          avatar: actor.avatar,
          universe: (actor.universe as Universe) || 'dragon_ball',
        });
        await new Promise((res) => setTimeout(res, 1200));
        setUltimateCutIn(null);
      } else if (skill.visualEffect === 'ki_beam') {
        sound.playKiBeam();
      } else if (skill.visualEffect === 'chidori_strike') {
        sound.playChidori();
      } else if (skill.visualEffect === 'crystal_blade') {
        sound.playBladeSlash();
      } else {
        sound.playHit();
      }

      // Handle Healing / Buffs
      if (skill.healingMultiplier && skill.healingMultiplier > 0) {
        sound.playHeal();
        if (actorIsHero) {
          const healer = heroes[actorIndex];
          const healAmount = calculateHealing(healer.currentAtk, skill.healingMultiplier);

          if (skill.target === 'all_allies') {
            setHeroes((prev) =>
              prev.map((h, idx) => {
                if (!h.isAlive) return h;
                const newHp = Math.min(h.maxHp, h.currentHp + healAmount);
                addFloatingNumber(true, idx, `+${healAmount}`, false, true);
                return { ...h, currentHp: newHp };
              })
            );
            setActionMessage(`${healer.name} usó ${skill.name} sanando a todo el equipo.`);
          } else {
            setHeroes((prev) =>
              prev.map((h, idx) => {
                if (idx !== selectedAllyIndex || !h.isAlive) return h;
                const newHp = Math.min(h.maxHp, h.currentHp + healAmount);
                addFloatingNumber(true, idx, `+${healAmount}`, false, true);
                return { ...h, currentHp: newHp };
              })
            );
            setActionMessage(`${healer.name} usó ${skill.name} sanando a ${heroes[selectedAllyIndex]?.name}.`);
          }
        }
      } else if (skill.target === 'self' || (skill.statusEffects && skill.multiplier === 0)) {
        // Self buff / team buff
        if (actorIsHero) {
          const buffActor = heroes[actorIndex];
          setHeroes((prev) =>
            prev.map((h, idx) => {
              if (idx !== actorIndex) return h;
              return {
                ...h,
                activeEffects: [...h.activeEffects, ...(skill.statusEffects || [])],
                nexusRage: Math.min(100, h.nexusRage + 20),
              };
            })
          );
          setActionMessage(`${buffActor.name} activó ${skill.name}.`);
        }
      } else {
        // Offensive damage skill
        triggerShake();
        if (actorIsHero) {
          const attacker = heroes[actorIndex];
          // Deduct energy or rage
          setHeroes((prev) =>
            prev.map((h, idx) => {
              if (idx !== actorIndex) return h;
              return {
                ...h,
                currentEnergy: Math.max(0, h.currentEnergy - skill.energyCost),
                nexusRage: skill.isUltimate ? 0 : Math.min(100, h.nexusRage + 15),
              };
            })
          );

          if (skill.target === 'all_enemies') {
            setEnemies((prev) =>
              prev.map((enemy, idx) => {
                if (!enemy.isAlive) return enemy;
                const dmgCalc = calculateDamage({
                  attackerAtk: attacker.currentAtk,
                  attackerElement: attacker.element,
                  defenderDef: enemy.def,
                  defenderElement: enemy.element,
                  skillMultiplier: skill.multiplier,
                  critChance: attacker.baseCrit,
                  activeEffects: attacker.activeEffects,
                });
                const newHp = Math.max(0, enemy.hp - dmgCalc.damage);
                addFloatingNumber(false, idx, `${dmgCalc.damage}`, dmgCalc.isCrit, false);
                return {
                  ...enemy,
                  hp: newHp,
                  isAlive: newHp > 0,
                };
              })
            );
            setActionMessage(`${attacker.name} desató ${skill.name} contra todos los enemigos.`);
          } else {
            // Single target
            setEnemies((prev) =>
              prev.map((enemy, idx) => {
                if (idx !== selectedEnemyIndex || !enemy.isAlive) return enemy;
                const dmgCalc = calculateDamage({
                  attackerAtk: attacker.currentAtk,
                  attackerElement: attacker.element,
                  defenderDef: enemy.def,
                  defenderElement: enemy.element,
                  skillMultiplier: skill.multiplier,
                  critChance: attacker.baseCrit,
                  activeEffects: attacker.activeEffects,
                });
                const newHp = Math.max(0, enemy.hp - dmgCalc.damage);
                addFloatingNumber(false, idx, `${dmgCalc.damage}`, dmgCalc.isCrit, false);
                return {
                  ...enemy,
                  hp: newHp,
                  isAlive: newHp > 0,
                };
              })
            );
            setActionMessage(`${attacker.name} usó ${skill.name} sobre ${enemies[selectedEnemyIndex]?.name}.`);
          }
        } else {
          // Enemy attacking hero
          const enemyAttacker = enemies[actorIndex];
          // Pick lowest HP living hero
          const livingHeroes = heroes
            .map((h, idx) => ({ ...h, idx }))
            .filter((h) => h.isAlive);

          if (livingHeroes.length > 0) {
            const targetHero = livingHeroes[Math.floor(Math.random() * livingHeroes.length)];

            if (skill.target === 'all_enemies') {
              setHeroes((prev) =>
                prev.map((h, idx) => {
                  if (!h.isAlive) return h;
                  const dmgCalc = calculateDamage({
                    attackerAtk: enemyAttacker.atk,
                    attackerElement: enemyAttacker.element,
                    defenderDef: h.currentDef,
                    defenderElement: h.element,
                    skillMultiplier: skill.multiplier,
                    critChance: enemyAttacker.crit,
                    activeEffects: enemyAttacker.activeEffects,
                  });
                  const newHp = Math.max(0, h.currentHp - dmgCalc.damage);
                  addFloatingNumber(true, idx, `${dmgCalc.damage}`, dmgCalc.isCrit, false);
                  return {
                    ...h,
                    currentHp: newHp,
                    isAlive: newHp > 0,
                    nexusRage: Math.min(100, h.nexusRage + 15),
                  };
                })
              );
              setActionMessage(`${enemyAttacker.name} lanzó ${skill.name} arrasando a tu escuadrón.`);
            } else {
              setHeroes((prev) =>
                prev.map((h, idx) => {
                  if (idx !== targetHero.idx || !h.isAlive) return h;
                  const dmgCalc = calculateDamage({
                    attackerAtk: enemyAttacker.atk,
                    attackerElement: enemyAttacker.element,
                    defenderDef: h.currentDef,
                    defenderElement: h.element,
                    skillMultiplier: skill.multiplier,
                    critChance: enemyAttacker.crit,
                    activeEffects: enemyAttacker.activeEffects,
                  });
                  const newHp = Math.max(0, h.currentHp - dmgCalc.damage);
                  addFloatingNumber(true, idx, `${dmgCalc.damage}`, dmgCalc.isCrit, false);
                  return {
                    ...h,
                    currentHp: newHp,
                    isAlive: newHp > 0,
                    nexusRage: Math.min(100, h.nexusRage + 20),
                  };
                })
              );
              setActionMessage(`${enemyAttacker.name} atacó con ${skill.name} a ${targetHero.name}.`);
            }
          }
        }
      }

      await new Promise((res) => setTimeout(res, 600));

      // Check battle conclusion
      const currentEnemiesAlive = enemies.filter((e) => e.isAlive).length;
      const currentHeroesAlive = heroes.filter((h) => h.isAlive).length;

      // Note: check with the updated state after this action
      // We advance turn in useEffect after state settles
      setBattleState('idle');
      turnInProgressRef.current = false;
    },
    [
      battleState,
      heroes,
      enemies,
      selectedEnemyIndex,
      selectedAllyIndex,
      addFloatingNumber,
      triggerShake,
    ]
  );

  // Initialize or re-evaluate turn queue
  useEffect(() => {
    // Check win condition
    const anyEnemyAlive = enemies.some((e) => e.isAlive);
    const anyHeroAlive = heroes.some((h) => h.isAlive);

    if (!anyEnemyAlive && battleState !== 'victory') {
      setBattleState('victory');
      sound.playVictory();
      confetti({
        particleCount: 80,
        spread: 90,
        origin: { y: 0.6 },
      });
      return;
    }

    if (!anyHeroAlive && battleState !== 'defeat') {
      setBattleState('defeat');
      return;
    }

    // Auto-fix selected enemy target if current target died
    if (!enemies[selectedEnemyIndex]?.isAlive) {
      const firstLiving = enemies.findIndex((e) => e.isAlive);
      if (firstLiving !== -1) {
        setSelectedEnemyIndex(firstLiving);
      }
    }

    // Advance turn queue if empty
    if (turnQueue.length === 0 && anyEnemyAlive && anyHeroAlive) {
      const newQueue = buildTurnQueue();
      setTurnQueue(newQueue);
      setRoundNumber((r) => r + 1);
    }
  }, [heroes, enemies, turnQueue.length, buildTurnQueue, battleState, selectedEnemyIndex]);

  // Turn execution loop
  useEffect(() => {
    if (battleState !== 'idle' || turnInProgressRef.current) return;
    if (turnQueue.length === 0) return;

    const [nextActor, ...remainingQueue] = turnQueue;
    setCurrentTurnActor(nextActor);

    // Verify if nextActor is still alive
    const actorAlive = nextActor.isHero
      ? heroes[nextActor.index]?.isAlive
      : enemies[nextActor.index]?.isAlive;

    if (!actorAlive) {
      // Skip dead combatant
      setTurnQueue(remainingQueue);
      return;
    }

    // If it's an enemy, execute AI turn after short windup
    if (!nextActor.isHero) {
      const enemy = enemies[nextActor.index];
      const timer = setTimeout(() => {
        // AI skill selection
        let skillToUse = enemy.basicAttack;
        if (enemy.ultimate && Math.random() < 0.3) {
          skillToUse = enemy.ultimate;
        } else if (enemy.skill1 && Math.random() < 0.5) {
          skillToUse = enemy.skill1;
        }
        executeAction(false, nextActor.index, skillToUse);
        setTurnQueue(remainingQueue);
      }, 700);

      return () => clearTimeout(timer);
    }
  }, [turnQueue, battleState, heroes, enemies, executeAction]);

  // Player action trigger
  const handlePlayerSkill = (skill: Skill) => {
    if (battleState !== 'idle' || !currentTurnActor || !currentTurnActor.isHero) return;
    const heroIndex = currentTurnActor.index;
    const hero = heroes[heroIndex];

    // Check energy requirements
    if (hero.currentEnergy < skill.energyCost) {
      setActionMessage(`¡Energía insuficiente para ${skill.name}!`);
      return;
    }

    // Check ultimate rage
    if (skill.isUltimate && hero.nexusRage < 100) {
      setActionMessage('¡La Furia del Nexo aún no está al 100%!');
      return;
    }

    const remaining = turnQueue.slice(1);
    executeAction(true, heroIndex, skill);
    setTurnQueue(remaining);
  };

  // Active hero
  const activeHero =
    currentTurnActor && currentTurnActor.isHero ? heroes[currentTurnActor.index] : null;

  // Total rewards calculated from enemies
  const totalGoldReward = enemies.reduce((acc, e) => acc + (e.drops?.gold || 500), 0);
  const totalExpReward = enemies.reduce((acc, e) => acc + (e.drops?.exp || 600), 0);
  const totalGemsReward = enemies.reduce((acc, e) => acc + (e.drops?.gems || 25), 0);

  return (
    <div
      className={`relative w-full h-full min-h-screen overflow-y-auto flex flex-col justify-between text-white bg-slate-950 select-none ${
        screenShake ? 'animate-energy-shake' : ''
      }`}
    >
      {/* Dynamic Background with dimensional vortex */}
      <div
        className="absolute inset-0 bg-cover bg-center brightness-75 transition-all duration-700"
        style={{ backgroundImage: `url(${bgImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-purple-950/40 to-black/80 pointer-events-none" />

      {/* Floating Damage & Healing Indicators */}
      <div className="absolute inset-0 pointer-events-none z-30">
        {floatingNumbers.map((num) => (
          <div
            key={num.id}
            className={`absolute font-black text-2xl sm:text-3xl animate-bounce drop-shadow-[0_4px_10px_rgba(0,0,0,0.9)] transition-all ${
              num.isHeal
                ? 'text-emerald-400'
                : num.isCrit
                ? 'text-amber-300 scale-125'
                : 'text-red-400'
            }`}
            style={{
              left: num.isHero ? `${15 + num.targetIndex * 15}%` : `${60 + num.targetIndex * 15}%`,
              top: '40%',
            }}
          >
            {num.isCrit && <span className="text-xs block text-yellow-300 font-bold uppercase">¡CRÍTICO!</span>}
            {num.text}
          </div>
        ))}
      </div>

      {/* Ultimate Limit Break Fullscreen Cut-in */}
      {ultimateCutIn && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md animate-fadeIn">
          <div className="relative w-full max-w-4xl px-6 flex flex-col md:flex-row items-center gap-8 text-center md:text-left">
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-500 via-purple-600 to-cyan-400 blur-2xl animate-spin" />
              <img
                src={ultimateCutIn.avatar}
                alt={ultimateCutIn.characterName}
                className="relative w-44 h-44 sm:w-56 sm:h-56 rounded-3xl border-4 border-amber-400 object-cover shadow-[0_0_50px_rgba(245,158,11,0.8)]"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-extrabold text-cyan-300 uppercase tracking-widest">
                ¡DEFINITIVA SUPREMA DEL NEXO!
              </span>
              <h2 className="text-3xl sm:text-5xl font-black font-title text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-400 to-red-400 my-1 drop-shadow-lg">
                {ultimateCutIn.skillName}
              </h2>
              <p className="text-lg sm:text-2xl font-bold text-white italic mt-2">
                "{ultimateCutIn.quote}"
              </p>
              <div className="mt-4 flex items-center gap-2">
                <span className="px-3 py-1 bg-purple-600/60 rounded-full text-xs font-bold uppercase tracking-wider text-purple-200 border border-purple-400">
                  {ultimateCutIn.characterName}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TOP HEADER: Battle info & Turn Order timeline */}
      <header className="relative z-10 w-full px-4 pt-3 flex flex-col gap-2">
        <div className="flex items-center justify-between bg-black/70 backdrop-blur-md px-4 py-2 rounded-2xl border border-purple-500/30">
          <div className="flex items-center gap-3">
            <span className="text-xs uppercase font-extrabold tracking-wider text-amber-400 font-title">
              {battleTitle}
            </span>
            <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
              Ronda {roundNumber}
            </span>
          </div>

          <p className="text-xs sm:text-sm text-cyan-200 font-medium truncate max-w-md hidden sm:block">
            {actionMessage}
          </p>

          <button
            onClick={onExit}
            className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300 bg-red-950/50 hover:bg-red-900/50 px-2.5 py-1 rounded-lg border border-red-500/40 transition active:scale-95 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Retirarse</span>
          </button>
        </div>

        {/* Turn Queue Timeline */}
        <div className="flex items-center gap-2 overflow-x-auto py-1 px-2 bg-slate-950/60 rounded-xl border border-white/10">
          <span className="text-[10px] font-bold uppercase text-slate-400 tracking-wider flex-shrink-0">
            Orden de Turno:
          </span>
          {turnQueue.slice(0, 8).map((actor, idx) => {
            const char = actor.isHero ? heroes[actor.index] : enemies[actor.index];
            if (!char) return null;
            const isCurrent = idx === 0;

            return (
              <div
                key={`${actor.isHero ? 'h' : 'e'}-${actor.index}-${idx}`}
                className={`relative flex items-center gap-1.5 px-2 py-1 rounded-xl transition-all flex-shrink-0 ${
                  isCurrent
                    ? actor.isHero
                      ? 'bg-amber-500/30 border-2 border-amber-400 scale-105 shadow-md'
                      : 'bg-red-500/30 border-2 border-red-500 scale-105 shadow-md'
                    : actor.isHero
                    ? 'bg-blue-950/40 border border-blue-500/30 opacity-75'
                    : 'bg-red-950/40 border border-red-500/30 opacity-75'
                }`}
              >
                <img
                  src={char.avatar}
                  alt={char.name}
                  className="w-6 h-6 rounded-full object-cover border border-white/30"
                />
                <span className="text-[11px] font-bold text-white max-w-[70px] truncate">
                  {char.name.split(' ')[0]}
                </span>
                <span className="text-[9px] text-slate-300 font-mono">
                  {actor.isHero ? (char as PlayerCharacter).currentSpd : (char as EnemyCharacter).spd} SPD
                </span>
              </div>
            );
          })}
        </div>
      </header>

      {/* COMBAT ARENA FIELD */}
      <main className="relative z-10 w-full max-w-7xl mx-auto px-4 py-4 flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-center">
          {/* HERO SQUAD (LEFT) */}
          <section className="flex flex-col gap-2.5">
            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-cyan-300 font-title border-b border-cyan-500/30 pb-1">
              <span>Escuadrón Aliado ({heroes.filter((h) => h.isAlive).length}/4)</span>
              <span>Convergencia Nexo Activa</span>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              {heroes.map((hero, idx) => {
                const isActive =
                  currentTurnActor?.isHero && currentTurnActor?.index === idx;
                const isSelectedAlly = selectedAllyIndex === idx;

                return (
                  <div
                    key={hero.id}
                    onClick={() => setSelectedAllyIndex(idx)}
                    className={`relative rounded-2xl p-2.5 transition-all cursor-pointer ${
                      !hero.isAlive
                        ? 'opacity-40 grayscale bg-slate-900/60 border border-slate-700'
                        : isActive
                        ? 'bg-gradient-to-r from-blue-900/60 to-purple-900/60 border-2 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.5)] scale-[1.02]'
                        : isSelectedAlly
                        ? 'bg-slate-900/80 border border-cyan-400'
                        : 'bg-slate-900/60 border border-white/10 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="relative">
                        <img
                          src={hero.avatar}
                          alt={hero.name}
                          className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover border border-amber-400/60 shadow"
                        />
                        <span className="absolute -top-1.5 -left-1.5 bg-purple-700 text-[10px] font-black px-1.5 rounded-full border border-purple-400">
                          {hero.rarity}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs sm:text-sm font-bold text-white truncate font-title">
                            {hero.name}
                          </h4>
                          {renderElementBadge(hero.element)}
                        </div>

                        {/* HP Bar */}
                        <div className="w-full bg-slate-950 rounded-full h-2 mt-1.5 overflow-hidden border border-white/10">
                          <div
                            className="h-full bg-gradient-to-r from-emerald-500 to-green-400 transition-all duration-300"
                            style={{
                              width: `${Math.max(0, (hero.currentHp / hero.maxHp) * 100)}%`,
                            }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-300 font-mono mt-0.5">
                          <span>HP</span>
                          <span>
                            {hero.currentHp} / {hero.maxHp}
                          </span>
                        </div>

                        {/* Energy & Rage meters */}
                        <div className="flex gap-2 mt-1">
                          {/* Energy Bar */}
                          <div className="flex-1 bg-slate-950 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="h-full bg-cyan-400 transition-all duration-300"
                              style={{ width: `${hero.currentEnergy}%` }}
                            />
                          </div>
                          {/* Ultimate Rage */}
                          <div className="flex-1 bg-slate-950 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="h-full bg-amber-400 transition-all duration-300"
                              style={{ width: `${hero.nexusRage}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* ENEMY SQUAD (RIGHT) */}
          <section className="flex flex-col gap-2.5">
            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-red-400 font-title border-b border-red-500/30 pb-1">
              <span>Fuerzas Hostiles ({enemies.filter((e) => e.isAlive).length}/{enemies.length})</span>
              <span>Toca un enemigo para fijar objetivo</span>
            </div>

            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              {enemies.map((enemy, idx) => {
                const isSelected = selectedEnemyIndex === idx;
                const isActive =
                  !currentTurnActor?.isHero && currentTurnActor?.index === idx;

                return (
                  <div
                    key={enemy.id + idx}
                    onClick={() => enemy.isAlive && setSelectedEnemyIndex(idx)}
                    className={`relative rounded-2xl p-2.5 transition-all cursor-pointer ${
                      !enemy.isAlive
                        ? 'opacity-30 grayscale bg-slate-900/50 border border-slate-800'
                        : isSelected
                        ? 'bg-gradient-to-r from-red-950/90 to-purple-950/90 border-2 border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.5)] scale-[1.02]'
                        : isActive
                        ? 'bg-red-900/40 border border-amber-400'
                        : 'bg-slate-900/60 border border-white/10 hover:border-white/30'
                    }`}
                  >
                    {/* Reticle target cursor */}
                    {isSelected && enemy.isAlive && (
                      <div className="absolute -top-2.5 -right-2.5 bg-red-600 text-white p-1 rounded-full shadow-lg border border-white animate-pulse">
                        <Crosshair className="w-3.5 h-3.5" />
                      </div>
                    )}

                    <div className="flex items-center gap-2.5">
                      <div className="relative">
                        <img
                          src={enemy.avatar}
                          alt={enemy.name}
                          className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover border border-red-500/60 shadow"
                        />
                        {enemy.isBoss && (
                          <span className="absolute -top-1.5 -left-1.5 bg-red-600 text-[10px] font-black px-1 rounded font-title text-white">
                            JEFE
                          </span>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs sm:text-sm font-bold text-white truncate font-title">
                            {enemy.name}
                          </h4>
                          {renderElementBadge(enemy.element)}
                        </div>

                        {/* HP Bar */}
                        <div className="w-full bg-slate-950 rounded-full h-2 mt-1.5 overflow-hidden border border-white/10">
                          <div
                            className="h-full bg-gradient-to-r from-red-600 to-orange-500 transition-all duration-300"
                            style={{
                              width: `${Math.max(0, (enemy.hp / enemy.maxHp) * 100)}%`,
                            }}
                          />
                        </div>
                        <div className="flex justify-between text-[10px] text-slate-300 font-mono mt-0.5">
                          <span>Nivel {enemy.level}</span>
                          <span>
                            {enemy.hp} / {enemy.maxHp}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      </main>

      {/* BOTTOM ACTION BAR (Active Hero Turn Control) */}
      <footer className="relative z-20 w-full bg-slate-950/90 backdrop-blur-md border-t border-purple-500/30 p-3 sm:p-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          {activeHero ? (
            <div className="flex items-center gap-3 w-full md:w-auto">
              <img
                src={activeHero.avatar}
                alt={activeHero.name}
                className="w-12 h-12 rounded-xl object-cover border-2 border-amber-400 shadow"
              />
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-sm sm:text-base font-title text-amber-300">
                    Turno de {activeHero.name}
                  </span>
                  <span className="text-xs text-cyan-300">
                    Energía: {activeHero.currentEnergy}/100
                  </span>
                </div>
                <p className="text-xs text-slate-400 italic truncate max-w-xs sm:max-w-md">
                  "{activeHero.quote}"
                </p>
              </div>
            </div>
          ) : (
            <div className="text-sm font-semibold text-slate-400">
              Esperando acción en combate...
            </div>
          )}

          {/* Action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 w-full md:w-auto">
            {activeHero && (
              <>
                {/* Basic Attack */}
                <button
                  onClick={() => handlePlayerSkill(activeHero.basicAttack)}
                  disabled={battleState !== 'idle'}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-600 text-white font-bold text-xs sm:text-sm flex flex-col items-center gap-0.5 transition active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  <span>{activeHero.basicAttack.name}</span>
                  <span className="text-[10px] text-slate-400 font-normal">Ataque Básico</span>
                </button>

                {/* Skill 1 */}
                <button
                  onClick={() => handlePlayerSkill(activeHero.skill1)}
                  disabled={
                    battleState !== 'idle' ||
                    activeHero.currentEnergy < activeHero.skill1.energyCost
                  }
                  className="px-4 py-2.5 rounded-xl bg-blue-900/80 hover:bg-blue-800 border border-blue-500/50 text-cyan-200 font-bold text-xs sm:text-sm flex flex-col items-center gap-0.5 transition active:scale-95 disabled:opacity-40 cursor-pointer"
                >
                  <span>{activeHero.skill1.name}</span>
                  <span className="text-[10px] text-cyan-300 font-mono">
                    {activeHero.skill1.energyCost} Energía
                  </span>
                </button>

                {/* Skill 2 */}
                <button
                  onClick={() => handlePlayerSkill(activeHero.skill2)}
                  disabled={
                    battleState !== 'idle' ||
                    activeHero.currentEnergy < activeHero.skill2.energyCost
                  }
                  className="px-4 py-2.5 rounded-xl bg-purple-900/80 hover:bg-purple-800 border border-purple-500/50 text-purple-200 font-bold text-xs sm:text-sm flex flex-col items-center gap-0.5 transition active:scale-95 disabled:opacity-40 cursor-pointer"
                >
                  <span>{activeHero.skill2.name}</span>
                  <span className="text-[10px] text-purple-300 font-mono">
                    {activeHero.skill2.energyCost} Energía
                  </span>
                </button>

                {/* Ultimate Limit Break */}
                <button
                  onClick={() => handlePlayerSkill(activeHero.ultimate)}
                  disabled={battleState !== 'idle' || activeHero.nexusRage < 100}
                  className={`px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm flex flex-col items-center gap-0.5 transition-all duration-200 cursor-pointer ${
                    activeHero.nexusRage >= 100
                      ? 'bg-gradient-to-r from-amber-500 via-orange-500 to-red-500 text-slate-950 shadow-[0_0_20px_rgba(245,158,11,0.8)] animate-pulse hover:scale-105 active:scale-95 border-2 border-amber-300'
                      : 'bg-slate-900 text-slate-500 border border-slate-800 opacity-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 fill-current" />
                    <span>¡DEFINITIVA!</span>
                  </div>
                  <span className="text-[10px] font-mono">
                    {activeHero.nexusRage}/100 Furia Nexo
                  </span>
                </button>
              </>
            )}
          </div>
        </div>
      </footer>

      {/* VICTORY MODAL */}
      {battleState === 'victory' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fadeIn">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-amber-400 rounded-3xl p-6 sm:p-8 max-w-md w-full text-center shadow-[0_0_40px_rgba(245,158,11,0.6)]">
            <Award className="w-16 h-16 text-amber-400 mx-auto mb-3 animate-bounce" />
            <span className="text-xs uppercase tracking-widest text-cyan-300 font-bold font-title">
              ¡Misión Cumplida!
            </span>
            <h2 className="text-3xl sm:text-4xl font-black font-title text-amber-300 my-1">
              ¡VICTORIA!
            </h2>
            <p className="text-xs text-slate-300 mb-6">
              Has derrotado a las anomalías de la fractura dimensional.
            </p>

            {/* Rewards tiles */}
            <div className="grid grid-cols-3 gap-2.5 bg-black/50 p-3.5 rounded-2xl border border-white/10 mb-6">
              <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-400 uppercase">Oro</span>
                <span className="text-sm font-bold text-amber-300">+{totalGoldReward}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-400 uppercase">Experiencia</span>
                <span className="text-sm font-bold text-cyan-300">+{totalExpReward}</span>
              </div>
              <div className="flex flex-col items-center">
                <span className="text-[10px] text-slate-400 uppercase">Gemas Nexo</span>
                <span className="text-sm font-bold text-purple-300">+{totalGemsReward}</span>
              </div>
            </div>

            <button
              onClick={() =>
                onVictory({
                  gold: totalGoldReward,
                  exp: totalExpReward,
                  gems: totalGemsReward,
                })
              }
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-base font-title uppercase tracking-wider shadow-lg transition active:scale-95 cursor-pointer"
            >
              Reclamar Recompensas
            </button>
          </div>
        </div>
      )}

      {/* DEFEAT MODAL */}
      {battleState === 'defeat' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fadeIn">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-red-500 rounded-3xl p-6 sm:p-8 max-w-md w-full text-center shadow-[0_0_40px_rgba(239,68,68,0.6)]">
            <AlertTriangle className="w-16 h-16 text-red-500 mx-auto mb-3" />
            <span className="text-xs uppercase tracking-widest text-red-400 font-bold font-title">
              Falla en el Continuo
            </span>
            <h2 className="text-3xl sm:text-4xl font-black font-title text-red-400 my-1">
              DERROTA
            </h2>
            <p className="text-xs text-slate-300 mb-6">
              Tu escuadrón ha caído ante el caos del Nexo. Mejora tus personajes con orbes de experiencia y despierta sus estrellas para triunfar.
            </p>

            <div className="flex gap-3">
              <button
                onClick={onDefeat}
                className="flex-1 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm transition active:scale-95 cursor-pointer"
              >
                Volver al Menú
              </button>
              <button
                onClick={() => {
                  setHeroes(
                    initialHeroes.map((h) => ({
                      ...h,
                      currentHp: h.maxHp,
                      currentEnergy: 60,
                      nexusRage: 30,
                      isAlive: true,
                      activeEffects: [],
                    }))
                  );
                  setEnemies(
                    initialEnemies.map((e) => ({
                      ...e,
                      hp: e.maxHp,
                      isAlive: true,
                      activeEffects: [],
                    }))
                  );
                  setBattleState('idle');
                  setRoundNumber(1);
                  setTurnQueue([]);
                }}
                className="flex-1 py-3 rounded-2xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm transition active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reintentar</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
