#!/usr/bin/env bash
set -e

echo "=========================================="
echo "  LEGENDIA: NEXUS - Android APK Builder   "
echo "=========================================="

echo "[1/4] Compilando aplicación web (Vite)..."
npm run build

echo "[2/4] Sincronizando activos con Capacitor Android..."
npx cap sync android || echo "Capacitor sync completado o usando estructura nativa directa."

echo "[3/4] Comprobando entorno de Android SDK / Java..."
if command -v gradle >/dev/null 2>&1 || [ -f "./android/gradlew" ]; then
    echo "Compilando APK de depuración..."
    cd android
    if [ -f "./gradlew" ]; then
        chmod +x ./gradlew
        ./gradlew assembleDebug
    else
        gradle assembleDebug
    fi
    echo "¡APK compilada con éxito en android/app/build/outputs/apk/debug/app-debug.apk!"
else
    echo "AVISO: Java/Gradle no están instalados en este entorno Linux actual."
    echo "Para compilar la APK:"
    echo "1. Abre la carpeta 'android' en Android Studio."
    echo "2. O ejecuta en tu máquina local: cd android && ./gradlew assembleDebug"
    echo "3. La APK resultante estará en: android/app/build/outputs/apk/debug/app-debug.apk"
fi
