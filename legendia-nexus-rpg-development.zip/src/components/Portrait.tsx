"use client";
import { CHAR_MAP } from "@/game/catalog";

const QUAD_POS = ["0% 0%", "100% 0%", "0% 100%", "100% 100%"];

export function Portrait({
  charKey, size, className = "", transformed = false, dim = false, style,
}: {
  charKey: string;
  size?: number | string;
  className?: string;
  transformed?: boolean;
  dim?: boolean;
  style?: React.CSSProperties;
}) {
  const def = CHAR_MAP[charKey];
  if (!def) return null;
  const dimStyle: React.CSSProperties = {
    backgroundImage: `url(/art/sheet${def.portrait.sheet}.jpg)`,
    backgroundSize: "200% 200%",
    backgroundPosition: QUAD_POS[def.portrait.quad],
    width: size ?? "100%",
    height: size ?? "100%",
    filter: dim
      ? "grayscale(1) brightness(0.35)"
      : transformed
        ? "saturate(1.5) hue-rotate(-14deg) contrast(1.12) brightness(1.1)"
        : undefined,
    ...style,
  };
  return (
    <div className={`relative overflow-hidden ${className}`} style={dimStyle}>
      {transformed && !dim && (
        <div
          className="pointer-events-none absolute inset-0 anim-pulse-soft"
          style={{ boxShadow: `inset 0 0 ${typeof size === "number" ? size / 3 : 24}px ${def.color}`, mixBlendMode: "screen" }}
        />
      )}
    </div>
  );
}

export function RarityStars({ rarity, className = "" }: { rarity: number; className?: string }) {
  return (
    <span className={`tracking-tighter ${rarity === 5 ? "text-amber-300" : rarity === 4 ? "text-yellow-400" : "text-sky-300"} ${className}`}>
      {"★".repeat(rarity)}
    </span>
  );
}

export function rarityFrame(rarity: number): string {
  if (rarity === 5) return "frame-r5";
  if (rarity === 4) return "frame-r4";
  return "frame-r3";
}